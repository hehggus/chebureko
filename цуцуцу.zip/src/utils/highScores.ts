import type { GameMode } from '../game/types.ts';

// Guideline Section 11.2: "unless the hardware does not allow it, the player
// should have access to the High Score table". Top-5 entries per mode,
// persisted in localStorage and ranked by score.

export interface HighScoreEntry {
  score: number;
  lines: number;
  level: number;
  timeMs: number;
  date: number;
}

const STORAGE_KEY = 'tetris_highscores_v1';
const MAX_ENTRIES = 5;

export type HighScoreTable = Record<GameMode, HighScoreEntry[]>;

function loadAll(): HighScoreTable {
  const empty: HighScoreTable = { marathon: [], sprint: [], ultra: [], freeplay: [] };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        marathon: Array.isArray(parsed.marathon) ? parsed.marathon : [],
        sprint: Array.isArray(parsed.sprint) ? parsed.sprint : [],
        ultra: Array.isArray(parsed.ultra) ? parsed.ultra : [],
        freeplay: Array.isArray(parsed.freeplay) ? parsed.freeplay : [],
      };
    }
  } catch (_) {
    // Corrupted storage: start fresh
  }
  return empty;
}

export function getHighScores(mode: GameMode): HighScoreEntry[] {
  return loadAll()[mode] ?? [];
}

export function submitScore(mode: GameMode, entry: HighScoreEntry): boolean {
  const all = loadAll();
  const list = all[mode] ?? [];
  list.push(entry);
  list.sort((a, b) => b.score - a.score);
  const trimmed = list.slice(0, MAX_ENTRIES);
  const placed = trimmed.indexOf(entry) >= 0;
  all[mode] = trimmed;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
  } catch (_) {
    // Storage full/unavailable: score just isn't kept
  }
  return placed;
}

import React from 'react';
import type { PieceType, GridStyle, ColorPalette, BlockSkin } from '../game/types.ts';
import { getPaletteColors, GRAYSCALE_COLORS, type PieceColorDef } from '../game/constants.ts';

interface MinoBlockProps {
  type: PieceType | null;
  isGhost?: boolean;
  isClearing?: boolean;
  isGrayscale?: boolean;
  isLocked?: boolean;
  row?: number;
  col?: number;
  gridStyle?: GridStyle;
  colorPalette?: ColorPalette;
  monochromeColor?: string;
  customPalette?: Record<PieceType, PieceColorDef>;
  blockSkin?: BlockSkin;
  hasBottomNeighbor?: boolean;
  hasRightNeighbor?: boolean;
  hasBottomRightNeighbor?: boolean;
  size?: number | string;
}

export const MinoBlock: React.FC<MinoBlockProps> = React.memo(({
  type,
  isGhost = false,
  isClearing = false,
  isGrayscale = false,
  isLocked = false,
  row = 0,
  col = 0,
  gridStyle = 'checkerboard',
  colorPalette = 'vivid_guideline',
  monochromeColor = '#94a3b8',
  customPalette,
  blockSkin = 'solid',
  hasBottomNeighbor = false,
  hasRightNeighbor = false,
  hasBottomRightNeighbor = false,
  size = '100%',
}) => {
  // Empty Matrix Cell rendering
  if (!type && !isClearing) {
    if (gridStyle === 'grid') {
      return (
        <div
          className="w-full h-full select-none"
          style={{
            width: size,
            height: size,
            border: '1px solid rgba(255, 255, 255, 0.38)',
          }}
        />
      );
    }
    // Default: 'checkerboard' - one completely transparent, the second neutral gray
    const isLightSquare = (row + col) % 2 === 0;
    return (
      <div
        className="w-full h-full select-none"
        style={{
          width: size,
          height: size,
          backgroundColor: isLightSquare ? '#55555c' : 'transparent',
        }}
      />
    );
  }

  // Row clearing flash
  if (isClearing) {
    return (
      <div
        className="w-full h-full select-none pointer-events-none relative animate-clearing-cell"
        style={{
          width: size,
          height: size,
          backgroundColor: '#ffffff',
          boxShadow: '0 0 10px #ffffff, 0 0 18px rgba(255, 255, 255, 0.65)',
        }}
      />
    );
  }

  const palette = customPalette || getPaletteColors(colorPalette, monochromeColor);
  const colors = isGrayscale ? GRAYSCALE_COLORS : (type ? palette[type] : GRAYSCALE_COLORS);

  // GHOST PIECE: semi-transparent colored fill
  if (isGhost) {
    return (
      <div
        className="w-full h-full box-border select-none"
        style={{
          width: size,
          height: size,
          backgroundColor: `${colors.solid}18`,
        }}
      />
    );
  }

  // Placed/locked blocks are slightly less saturated/bright so active piece clearly pops
  const lockedFilter = isLocked ? 'saturate(0.85) brightness(0.92)' : undefined;

  // SOLID: seamless flat blocks. LINES: each mino gets a black inset border,
  // so adjacent cells read as classic separate blocks with black seams.
  const hasBlackLines = blockSkin === 'lines';

  return (
    <div
      className="w-full h-full box-border relative select-none"
      style={{
        width: size || '100%',
        height: size || '100%',
        backgroundColor: colors.solid,
        border: hasBlackLines ? '1px solid #000000' : undefined,
        filter: lockedFilter,
      }}
    >
      {!hasBlackLines && hasRightNeighbor && (
        <div
          className="absolute top-0 bottom-0 pointer-events-none"
          style={{ right: '-1px', width: '1px', backgroundColor: colors.solid }}
        />
      )}
      {!hasBlackLines && hasBottomNeighbor && (
        <div
          className="absolute left-0 right-0 pointer-events-none"
          style={{ bottom: '-1px', height: '1px', backgroundColor: colors.solid }}
        />
      )}
      {!hasBlackLines && hasRightNeighbor && hasBottomNeighbor && hasBottomRightNeighbor && (
        <div
          className="absolute pointer-events-none"
          style={{
            right: '-1px',
            bottom: '-1px',
            width: '1px',
            height: '1px',
            backgroundColor: colors.solid,
          }}
        />
      )}
    </div>
  );
});

MinoBlock.displayName = 'MinoBlock';

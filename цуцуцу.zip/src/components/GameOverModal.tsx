import React from 'react';
import type { GameMode, GameStats, Language } from '../game/types.ts';
import { formatTime } from '../game/rules.ts';
import { RotateCcw } from 'lucide-react';
import { TRANSLATIONS } from '../game/i18n.ts';

interface GameOverModalProps {
  isGameOver: boolean;
  isWon: boolean;
  stats: GameStats;
  mode: GameMode;
  language?: Language;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isGameOver,
  isWon,
  stats,
  mode,
  language = 'en',
  onRestart,
}) => {
  if (!isGameOver && !isWon) return null;
  const t = TRANSLATIONS[language];

  const secondsElapsed = Math.max(0.1, stats.timeElapsed / 1000);
  const pps = (stats.pieces / secondsElapsed).toFixed(2);

  const statItems = [
    {
      label: t.time,
      value: formatTime(stats.timeElapsed),
    },
    {
      label: t.lines,
      value: stats.lines.toString(),
    },
    {
      label: 'PIECES (SPEED)',
      value: `${stats.pieces} (${pps} PPS)`,
    },
    {
      label: 'TETRISES / T-SPINS',
      value: `${stats.tetrises} / ${stats.tspins}`,
    },
    {
      label: t.maxCombo.toUpperCase(),
      value: stats.maxCombo > 0 ? `${stats.maxCombo}x` : '0',
    },
    {
      label: 'BACK-TO-BACK',
      value: stats.b2bCount.toString(),
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="bg-[#18181c] border border-zinc-700/60 rounded-lg w-full max-w-sm p-4 sm:p-5 shadow-2xl text-zinc-200 font-sans">
        {/* Header Status */}
        <h2 className="text-base font-bold font-mono tracking-wider uppercase mb-0.5 text-center pt-1">
          {isWon ? (
            <span className="text-emerald-400">{t.victory}</span>
          ) : (
            <span className="text-zinc-200">{t.gameOver}</span>
          )}
        </h2>
        <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-mono mb-3 text-center">
          {`MODE ${t.modes[mode].name.toUpperCase()}`}
        </p>

        {/* Primary Score Banner */}
        <div className="bg-white/[0.03] py-2.5 px-4 rounded-md border border-white/[0.06] mb-3 text-center">
          <span className="text-[10px] text-zinc-500 uppercase tracking-wider block font-mono">
            FINAL SCORE
          </span>
          <span className="text-2xl sm:text-3xl font-bold text-white font-mono tracking-tight">
            {stats.score.toLocaleString()}
          </span>
        </div>

        {/* Clean Vertical Stat List */}
        <div className="bg-white/[0.02] rounded-md border border-white/[0.06] divide-y divide-white/[0.04] text-xs font-mono mb-4 overflow-hidden">
          {statItems.map((item) => (
            <div
              key={item.label}
              className="flex items-center justify-between px-3 py-1.5"
            >
              <span className="text-zinc-500 text-[10px] font-medium tracking-wide">
                {item.label}
              </span>
              <span className="font-bold text-zinc-200">
                {item.value}
              </span>
            </div>
          ))}
        </div>

        {/* Restart Button */}
        <button
          type="button"
          onClick={onRestart}
          className="w-full py-2.5 rounded-md bg-white hover:bg-zinc-200 active:bg-zinc-300 text-zinc-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer font-mono"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          {t.playAgain}
        </button>
      </div>
    </div>
  );
};

import React, { useMemo } from 'react';
import type {
  ActivePiece,
  BoardMatrix,
  HardDropTrailData,
  HardDropImpactData,
  LockFlashData,
  PieceType,
  GridStyle,
  ColorPalette,
  GhostStyle,
  GhostColor,
  BlockSkin,
} from '../game/types.ts';
import {
  PIECE_SHAPES,
  COLOR_PALETTES,
  getPaletteColors,
  VISIBLE_START_ROW,
  MATRIX_TOTAL_HEIGHT,
  GHOST_GRAY_COLOR,
} from '../game/constants.ts';
import { MinoBlock } from './MinoBlock.tsx';

// Stroke widths are in screen pixels (vectorEffect="non-scaling-stroke").
// The white outline is a narrow stroke drawn exactly on the locked-cell
// boundary. The locked-cell mask hides its inner half, so a ~1.8 px white
// line hugs the outer edge of the stack with no dark gap.
const WHITE_OUTLINE_STROKE_WIDTH = 3.6;

// Ghost outline metrics, expressed in board-cell units (the board SVG uses a
// 10 x 20 viewBox, so 1 unit = one cell = ~25 px). The outline is pulled
// GHOST_OUTLINE_INSET cells away from the silhouette edge and is
// GHOST_OUTLINE_WIDTH cells thick, so it sits clearly inside the figure.
const GHOST_OUTLINE_INSET = 0.08;
const GHOST_OUTLINE_WIDTH = 0.06;
// The outline uses a non-scaling stroke, so its width must be in screen
// pixels: the stroke has to cover the inset plus the visible band on both
// sides of the silhouette edge (the outer half is clipped away).
const GHOST_OUTLINE_STROKE_PX = (GHOST_OUTLINE_INSET + GHOST_OUTLINE_WIDTH) * 2 * 25;
// Width of the black band in the inset mask. It is centred on the silhouette
// edge, so its inner half hides exactly GHOST_OUTLINE_INSET of the outline.
const GHOST_OUTLINE_MASK_WIDTH_PX = GHOST_OUTLINE_INSET * 2 * 25;

// Glow is deliberately restrained so the crisp lines stay readable.
const WHITE_GLOW_TIGHT_OPACITY = 0.35;
const WHITE_GLOW_WIDE_OPACITY = 0.2;
const GHOST_HALO_OPACITY = 0.38;

interface TetrisBoardProps {
  board: BoardMatrix;
  activePiece: ActivePiece | null;
  ghostY: number;
  clearingRows: number[];
  showGhost: boolean;
  ghostStyle?: GhostStyle;
  ghostColor?: GhostColor;
  blockSkin?: BlockSkin;
  ghostOpacity?: number;
  gridOpacity?: number;
  ghostOutline?: boolean;
  showWhiteOutline?: boolean;
  whiteOutlineOpacity?: number;
  softPieceGlow?: boolean;
  matrixShakeEnabled?: boolean;
  impactParticlesEnabled?: boolean;
  lockFlashEnabled?: boolean;
  lineClearEffectsEnabled?: boolean;
  gridStyle?: GridStyle;
  colorPalette?: ColorPalette;
  monochromeColor?: string;
  hardDropTrail: HardDropTrailData | null;
  hardDropImpact: HardDropImpactData | null;
  matrixShake?: 'drop' | 'bump-left' | 'bump-right' | null;
  lockFlash: LockFlashData | null;
  isPaused: boolean;
}

export const TetrisBoard: React.FC<TetrisBoardProps> = React.memo(({
  board,
  activePiece,
  ghostY,
  clearingRows,
  showGhost,
  ghostStyle = 'solid',
  ghostColor: ghostColorProp = 'colored',
  blockSkin = 'solid',
  ghostOpacity = 0.05,
  gridOpacity = 0.35,
  ghostOutline = true,
  showWhiteOutline = true,
  whiteOutlineOpacity = 1,
  softPieceGlow = true,
  matrixShakeEnabled = true,
  impactParticlesEnabled = true,
  lockFlashEnabled = true,
  lineClearEffectsEnabled = true,
  gridStyle = 'checkerboard',
  colorPalette = 'vivid_guideline',
  monochromeColor = '#94a3b8',
  hardDropTrail,
  hardDropImpact,
  matrixShake = null,
  lockFlash,
  isPaused,
}) => {
  const visibleRowsCount = 20;
  const colsCount = 10;
  const palette = useMemo(
    () => getPaletteColors(colorPalette, monochromeColor),
    [colorPalette, monochromeColor]
  );

  // Active piece cells map with neighbor connectivity (used by the solid skin
  // to draw seamless 1px bridges between adjacent minoes)
  const activeCellData = useMemo(() => {
    const map = new Map<
      string,
      {
        type: PieceType;
        hasBottom: boolean;
        hasRight: boolean;
        hasBottomRight: boolean;
      }
    >();

    if (!activePiece || isPaused) return map;

    const shape = PIECE_SHAPES[activePiece.type][activePiece.rotation];
    const sRows = shape.length;
    const sCols = shape[0].length;

    for (let r = 0; r < sRows; r++) {
      for (let c = 0; c < sCols; c++) {
        if (shape[r][c] !== 0) {
          const by = activePiece.y + r;
          const bx = activePiece.x + c;
          if (
            by >= VISIBLE_START_ROW &&
            by < VISIBLE_START_ROW + visibleRowsCount &&
            bx >= 0 &&
            bx < colsCount
          ) {
            map.set(`${by}-${bx}`, {
              type: activePiece.type,
              hasBottom: r < sRows - 1 && shape[r + 1][c] !== 0,
              hasRight: c < sCols - 1 && shape[r][c + 1] !== 0,
              hasBottomRight:
                r < sRows - 1 && c < sCols - 1 && shape[r + 1][c + 1] !== 0,
            });
          }
        }
      }
    }
    return map;
  }, [activePiece, isPaused]);

  // Ghost piece cells set
  const ghostCellSet = useMemo(() => {
    const map = new Map<string, PieceType>();
    if (!activePiece || !showGhost || isPaused || ghostY === activePiece.y) {
      return map;
    }
    const shape = PIECE_SHAPES[activePiece.type][activePiece.rotation];
    const sRows = shape.length;
    const sCols = shape[0].length;

    for (let r = 0; r < sRows; r++) {
      for (let c = 0; c < sCols; c++) {
        if (shape[r][c] !== 0) {
          const by = ghostY + r;
          const bx = activePiece.x + c;
          if (
            by >= VISIBLE_START_ROW &&
            by < VISIBLE_START_ROW + visibleRowsCount &&
            bx >= 0 &&
            bx < colsCount
          ) {
            if (!activeCellData.has(`${by}-${bx}`)) {
              map.set(`${by}-${bx}`, activePiece.type);
            }
          }
        }
      }
    }
    return map;
  }, [activePiece, showGhost, isPaused, ghostY, activeCellData]);

  // Ghost piece cells coordinates for SVG rendering
  const ghostCoords = useMemo(() => {
    const list: { gx: number; vr: number }[] = [];
    if (!activePiece || !showGhost || isPaused || ghostY === activePiece.y) {
      return list;
    }
    const shape = PIECE_SHAPES[activePiece.type][activePiece.rotation];
    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c] !== 0) {
          const by = ghostY + r;
          const bx = activePiece.x + c;
          const vr = by - VISIBLE_START_ROW;
          if (vr >= 0 && vr < visibleRowsCount && bx >= 0 && bx < colsCount) {
            list.push({ gx: bx, vr });
          }
        }
      }
    }
    return list;
  }, [activePiece, showGhost, isPaused, ghostY]);

  // Seamless continuous closed polygon path for GHOST piece contour (Solid style)
  const isSolidGhost = ghostStyle === 'solid' || (ghostStyle as string) === 'outline';
  const isSeparatedGhost = ghostStyle === 'separated' || (ghostStyle as string) === 'cells';

  const ghostContourPath = useMemo(() => {
    if (!isSolidGhost || ghostCoords.length === 0) return '';
    const cellSet = new Set(ghostCoords.map((pt) => `${pt.gx},${pt.vr}`));
    const edgeMap = new Map<string, [number, number]>();

    for (const pt of ghostCoords) {
      const { gx, vr } = pt;
      if (!cellSet.has(`${gx},${vr - 1}`)) {
        edgeMap.set(`${gx},${vr}`, [gx + 1, vr]);
      }
      if (!cellSet.has(`${gx + 1},${vr}`)) {
        edgeMap.set(`${gx + 1},${vr}`, [gx + 1, vr + 1]);
      }
      if (!cellSet.has(`${gx},${vr + 1}`)) {
        edgeMap.set(`${gx + 1},${vr + 1}`, [gx, vr + 1]);
      }
      if (!cellSet.has(`${gx - 1},${vr}`)) {
        edgeMap.set(`${gx},${vr + 1}`, [gx, vr]);
      }
    }

    if (edgeMap.size === 0) return '';
    const startKey = edgeMap.keys().next().value!;
    const [startX, startY] = startKey.split(',').map(Number);
    let currKey = startKey;
    const pathParts: string[] = [`M ${startX} ${startY}`];
    const visited = new Set<string>();

    while (currKey && !visited.has(currKey)) {
      visited.add(currKey);
      const nextPt = edgeMap.get(currKey);
      if (!nextPt) break;
      currKey = `${nextPt[0]},${nextPt[1]}`;
      if (currKey === startKey) break;
      pathParts.push(`L ${nextPt[0]} ${nextPt[1]}`);
    }
    pathParts.push('Z');
    return pathParts.join(' ');
  }, [isSolidGhost, ghostCoords]);

  // Check if cell is in lock down flash
  const lockFlashMap = useMemo(() => {
    const set = new Set<string>();
    if (!lockFlash) return set;
    for (const cell of lockFlash.cells) {
      set.add(`${cell.y}-${cell.x}`);
    }
    return set;
  }, [lockFlash]);

  // Continuous SVG perimeter outline for the assembled locked mass.
  // The segments lie exactly on the cell boundary; the wider white stroke
  // and the black trim drawn over it create the outward gap.
  const whiteSegments = useMemo(() => {
    if (!showWhiteOutline) return [];
    const segments: { x1: number; y1: number; x2: number; y2: number; key: string }[] = [];

    for (let r = 0; r < visibleRowsCount; r++) {
      const actualRow = VISIBLE_START_ROW + r;
      for (let c = 0; c < colsCount; c++) {
        if (board[actualRow]?.[c] !== null) {
          if (actualRow > 0 && board[actualRow - 1]?.[c] === null) {
            segments.push({ x1: c, y1: r, x2: c + 1, y2: r, key: `top-${r}-${c}` });
          }
          if (actualRow < MATRIX_TOTAL_HEIGHT - 1 && board[actualRow + 1]?.[c] === null) {
            segments.push({ x1: c, y1: r + 1, x2: c + 1, y2: r + 1, key: `bot-${r}-${c}` });
          }
          if (c === 0 || board[actualRow]?.[c - 1] === null) {
            segments.push({ x1: c, y1: r, x2: c, y2: r + 1, key: `left-${r}-${c}` });
          }
          if (c === colsCount - 1 || board[actualRow]?.[c + 1] === null) {
            segments.push({ x1: c + 1, y1: r, x2: c + 1, y2: r + 1, key: `right-${r}-${c}` });
          }
        }
      }
    }
    return segments;
  }, [board, showWhiteOutline]);

  // Locked cells coordinates for masking the white silhouette strictly to the outside of blocks
  const lockedCells = useMemo(() => {
    if (!showWhiteOutline) return [];
    const list: { c: number; r: number }[] = [];
    for (let r = 0; r < visibleRowsCount; r++) {
      const actualRow = VISIBLE_START_ROW + r;
      for (let c = 0; c < colsCount; c++) {
        if (board[actualRow]?.[c] !== null) {
          list.push({ c, r });
        }
      }
    }
    return list;
  }, [board, showWhiteOutline]);

  const ghostColor =
    ghostColorProp === 'gray'
      ? GHOST_GRAY_COLOR
      : activePiece
      ? palette[activePiece.type].solid
      : '#3fe3ff';

  // Subtle matrix shake class applied strictly when matrixShakeEnabled is true
  const shakeClass =
    !matrixShakeEnabled
      ? ''
      : matrixShake === 'drop'
      ? 'animate-matrix-dip'
      : matrixShake === 'bump-left'
      ? 'animate-matrix-bump-left'
      : matrixShake === 'bump-right'
      ? 'animate-matrix-bump-right'
      : '';

  const effectiveWhiteOutlineOpacity = Number.isFinite(whiteOutlineOpacity)
    ? Math.max(0, Math.min(1, whiteOutlineOpacity))
    : 1;

  // Group contiguous clearing rows into unified bands to prevent muddy blur overlaps on multiple lines
  const clearingBands = useMemo(() => {
    if (clearingRows.length === 0) return [];
    const sorted = [...clearingRows].sort((a, b) => a - b);
    const bands: { startRow: number; rowCount: number }[] = [];
    let current = { startRow: sorted[0], rowCount: 1 };
    for (let i = 1; i < sorted.length; i++) {
      if (sorted[i] === current.startRow + current.rowCount) {
        current.rowCount++;
      } else {
        bands.push(current);
        current = { startRow: sorted[i], rowCount: 1 };
      }
    }
    bands.push(current);
    return bands;
  }, [clearingRows]);

  return (
    <div className="relative select-none flex justify-center flex-shrink-0">
      {/* The 10x20 Matrix */}
      <div
        data-testid="tetris-matrix"
        className={`aspect-[10/20] bg-black relative overflow-hidden outline-none ${shakeClass}`}
        style={{
          width: 'clamp(200px, 48vh, 250px)',
          borderLeft: '2px solid #ffffff',
          borderRight: '2px solid #ffffff',
          borderBottom: '2px solid #ffffff',
          borderTop: 'none',
        }}
      >
        {/* Background playfield grid layer */}
        <div
          className="absolute inset-0 grid grid-cols-10 grid-rows-[repeat(20,minmax(0,1fr))] pointer-events-none"
          style={{ opacity: gridOpacity }}
        >
          {Array.from({ length: visibleRowsCount }).map((_, rIdx) =>
            Array.from({ length: colsCount }).map((_, cIdx) => (
              <div key={`bg-${rIdx}-${cIdx}`} className="w-full h-full">
                <MinoBlock
                  type={null}
                  isClearing={false}
                  gridStyle={gridStyle}
                  row={rIdx}
                  col={cIdx}
                />
              </div>
            ))
          )}
        </div>

        {/* Main Pieces & Playing Matrix Layer */}
        <div className="absolute inset-0 grid grid-cols-10 grid-rows-[repeat(20,minmax(0,1fr))] z-10">
          {isPaused ? (
            <div className="col-span-10 row-span-20 bg-black/95 flex flex-col items-center justify-center z-30">
              <span className="text-xl font-bold font-mono tracking-widest text-zinc-200">
                PAUSED
              </span>
              <span className="text-xs text-zinc-500 mt-2 font-mono">
                Press Pause to Resume
              </span>
            </div>
          ) : (
            Array.from({ length: visibleRowsCount }).map((_, rIdx) => {
              const actualRow = VISIBLE_START_ROW + rIdx;
              const isClearing = lineClearEffectsEnabled && clearingRows.includes(actualRow);

              return Array.from({ length: colsCount }).map((_, cIdx) => {
                const key = `${actualRow}-${cIdx}`;
                const activeData = activeCellData.get(key);
                const ghostType = ghostCellSet.get(key);
                const lockedType = board[actualRow]?.[cIdx];

                if (activeData) {
                  return (
                    <div key={key} className="w-full h-full relative">
                      <MinoBlock
                        type={activeData.type}
                        isGhost={false}
                        isLocked={false}
                        isClearing={isClearing}
                        gridStyle={gridStyle}
                        colorPalette={colorPalette}
                        monochromeColor={monochromeColor}
                        customPalette={palette}
                        blockSkin={blockSkin}
                        hasBottomNeighbor={activeData.hasBottom}
                        hasRightNeighbor={activeData.hasRight}
                        hasBottomRightNeighbor={activeData.hasBottomRight}
                        row={rIdx}
                        col={cIdx}
                      />
                    </div>
                  );
                }

                if (ghostType) {
                  return <div key={key} className="w-full h-full relative" />;
                }

                if (lockedType) {
                  const hasBottom =
                    actualRow < MATRIX_TOTAL_HEIGHT - 1 &&
                    board[actualRow + 1]?.[cIdx] === lockedType;
                  const hasRight =
                    cIdx < colsCount - 1 && board[actualRow]?.[cIdx + 1] === lockedType;
                  const hasBottomRight =
                    actualRow < MATRIX_TOTAL_HEIGHT - 1 &&
                    cIdx < colsCount - 1 &&
                    board[actualRow + 1]?.[cIdx + 1] === lockedType;

                  return (
                    <div key={key} className="w-full h-full relative">
                      <MinoBlock
                        type={lockedType}
                        isGhost={false}
                        isLocked={true}
                        isClearing={isClearing}
                        gridStyle={gridStyle}
                        colorPalette={colorPalette}
                        monochromeColor={monochromeColor}
                        customPalette={palette}
                        blockSkin={blockSkin}
                        hasBottomNeighbor={hasBottom}
                        hasRightNeighbor={hasRight}
                        hasBottomRightNeighbor={hasBottomRight}
                        row={rIdx}
                        col={cIdx}
                      />
                    </div>
                  );
                }

                return <div key={key} className="w-full h-full relative" />;
              });
            })
          )}
        </div>

        {/* GHOST GLOW (Solid): own layer BELOW the blocks (z-5) and above the
            playfield, so the halo only shows through empty cells and never
            washes over already locked pieces. */}
        {showGhost && isSolidGhost && ghostContourPath && softPieceGlow && !isPaused && (
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-[5]"
            viewBox="0 0 10 20"
            preserveAspectRatio="none"
          >
            <defs>
              <filter id="ghost-solid-halo" filterUnits="userSpaceOnUse" x="-1" y="-1" width="12" height="22">
                <feGaussianBlur in="SourceGraphic" stdDeviation="0.12" result="tight" />
                <feGaussianBlur in="SourceGraphic" stdDeviation="0.28" result="wide" />
                <feMerge>
                  <feMergeNode in="tight" />
                  <feMergeNode in="wide" />
                </feMerge>
              </filter>
            </defs>
            <path
              d={ghostContourPath}
              fill={ghostColor}
              fillOpacity={ghostOpacity}
              stroke={ghostColor}
              strokeWidth="1.4"
              strokeLinejoin="round"
              vectorEffect="non-scaling-stroke"
              opacity={GHOST_HALO_OPACITY}
              filter="url(#ghost-solid-halo)"
            />
          </svg>
        )}

        {/* GHOST PIECE: Variant 1 (Solid / Continuous Closed Outline with INWARD-ONLY inline stroke) */}
        {showGhost && isSolidGhost && ghostContourPath && !isPaused && (
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-15"
            viewBox="0 0 10 20"
            preserveAspectRatio="none"
          >
            <defs>
              <clipPath id="ghost-inner-contour-clip">
                <path d={ghostContourPath} />
              </clipPath>

              {/* Hide a thin band along the silhouette edge: a white mask with
                  a black stroke of double the inset width. The stroke covers
                  GHOST_OUTLINE_INSET on both sides of the edge, so the visible
                  outline starts inside the figure. (A feMorphology mask is not
                  used here: in Chrome it can blank the mask completely.) */}
              <mask id="ghost-outline-inset-mask" maskUnits="userSpaceOnUse" x="-1" y="-1" width="12" height="22">
                <rect x="-1" y="-1" width="12" height="22" fill="#ffffff" />
                <path
                  d={ghostContourPath}
                  fill="none"
                  stroke="#000000"
                  strokeWidth={GHOST_OUTLINE_MASK_WIDTH_PX}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  vectorEffect="non-scaling-stroke"
                />
              </mask>
            </defs>
            <path
              d={ghostContourPath}
              fill={ghostColor}
              fillOpacity={ghostOpacity}
            />
            {ghostOutline && (
              <path
                d={ghostContourPath}
                fill="none"
                stroke={ghostColor}
                strokeWidth={GHOST_OUTLINE_STROKE_PX}
                strokeLinecap="round"
                strokeLinejoin="round"
                vectorEffect="non-scaling-stroke"
                clipPath="url(#ghost-inner-contour-clip)"
                mask="url(#ghost-outline-inset-mask)"
              />
            )}
          </svg>
        )}

        {/* GHOST GLOW (Separated): own layer BELOW the blocks (z-5) so the
            halo stays behind locked pieces and only shows on empty cells. */}
        {showGhost && isSeparatedGhost && ghostCoords.length > 0 && softPieceGlow && !isPaused && (
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-[5]"
            viewBox="0 0 10 20"
            preserveAspectRatio="none"
          >
            <defs>
              <filter id="ghost-separated-halo" filterUnits="userSpaceOnUse" x="-1" y="-1" width="12" height="22">
                <feGaussianBlur in="SourceGraphic" stdDeviation="0.12" result="tight" />
                <feGaussianBlur in="SourceGraphic" stdDeviation="0.28" result="wide" />
                <feMerge>
                  <feMergeNode in="tight" />
                  <feMergeNode in="wide" />
                </feMerge>
              </filter>
            </defs>
            {ghostCoords.map((c, i) => (
              <rect
                key={`ghost-halo-sq-${i}`}
                x={c.gx + 0.04}
                y={c.vr + 0.04}
                width={0.92}
                height={0.92}
                rx="0.08"
                fill={ghostColor}
                fillOpacity={ghostOpacity}
                stroke={ghostColor}
                strokeWidth="1.4"
                vectorEffect="non-scaling-stroke"
                opacity={GHOST_HALO_OPACITY}
                filter="url(#ghost-separated-halo)"
              />
            ))}
          </svg>
        )}

        {/* GHOST PIECE: Variant 2 (Separated / Outlined Squares).
            Each cell has a fill rect plus a smaller inset stroke rect, so the
            border sits inside the figure instead of on its outer edge. */}
        {showGhost && isSeparatedGhost && ghostCoords.length > 0 && !isPaused && (
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-15"
            viewBox="0 0 10 20"
            preserveAspectRatio="none"
          >
            {ghostCoords.map((c, i) => (
              <g key={`ghost-sq-${i}`}>
                <rect
                  x={c.gx + 0.04}
                  y={c.vr + 0.04}
                  width={0.92}
                  height={0.92}
                  rx="0.08"
                  fill={ghostColor}
                  fillOpacity={ghostOpacity}
                />
                {ghostOutline && (
                  <rect
                    x={c.gx + 0.08}
                    y={c.vr + 0.08}
                    width={0.84}
                    height={0.84}
                    rx="0.08"
                    fill="none"
                    stroke={ghostColor}
                    strokeWidth="1.4"
                    vectorEffect="non-scaling-stroke"
                  />
                )}
              </g>
            ))}
          </svg>
        )}

        {/* Continuous White Silhouette Outline: a wide white stroke plus a
            narrower black trim on top creates a small outward gap between
            the stack and the white ring. Both are masked inside the stack. */}
        {showWhiteOutline && whiteSegments.length > 0 && !isPaused && (
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-20"
            viewBox="0 0 10 20"
            preserveAspectRatio="none"
            /* Opacity is applied once to the whole layer. Per-segment
               strokeOpacity made overlapping square caps accumulate alpha
               and produced dashed artifacts at low transparency. */
            style={{ opacity: effectiveWhiteOutlineOpacity }}
          >
            <defs>
              <mask id="locked-mass-outside-mask">
                <rect x="0" y="0" width="10" height="20" fill="white" />
                {lockedCells.map((cell) => (
                  <rect
                    key={`locked-mask-${cell.r}-${cell.c}`}
                    x={cell.c}
                    y={cell.r}
                    width="1"
                    height="1"
                    fill="black"
                  />
                ))}
              </mask>
              {/* White glow: faint blurred copies are merged with the crisp
                  source, so the outline stays sharp while the halo remains
                  subtle. The explicit region prevents a clipped edge. */}
              <filter id="white-outline-glow" filterUnits="userSpaceOnUse" x="-1" y="-1" width="12" height="22">
                <feGaussianBlur in="SourceGraphic" stdDeviation="0.07" result="tight" />
                <feGaussianBlur in="SourceGraphic" stdDeviation="0.16" result="wide" />
                <feComponentTransfer in="tight" result="tightFaint">
                  <feFuncA type="linear" slope={WHITE_GLOW_TIGHT_OPACITY} />
                </feComponentTransfer>
                <feComponentTransfer in="wide" result="wideFaint">
                  <feFuncA type="linear" slope={WHITE_GLOW_WIDE_OPACITY} />
                </feComponentTransfer>
                <feMerge>
                  <feMergeNode in="wideFaint" />
                  <feMergeNode in="tightFaint" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <g
              mask="url(#locked-mass-outside-mask)"
              filter={softPieceGlow ? 'url(#white-outline-glow)' : undefined}
            >
              {whiteSegments.map((seg) => (
                <line
                  key={seg.key}
                  x1={seg.x1}
                  y1={seg.y1}
                  x2={seg.x2}
                  y2={seg.y2}
                  stroke="#ffffff"
                  strokeWidth={WHITE_OUTLINE_STROKE_WIDTH}
                  strokeLinecap="square"
                  vectorEffect="non-scaling-stroke"
                />
              ))}
            </g>
          </svg>
        )}

        {/* Lock Flash: Cascade Light & Spin Flash */}
        {lockFlashEnabled && lockFlash && !isPaused && (
          <div className="absolute inset-0 pointer-events-none z-25 overflow-visible">
            {(() => {
              const startX = lockFlash.minX * 10;
              const widthPct = (lockFlash.maxX - lockFlash.minX + 1) * 10;
              const topY = Math.max(0, ((lockFlash.minY - VISIBLE_START_ROW) / visibleRowsCount) * 100);
              const botY = Math.min(100, ((lockFlash.maxY - VISIBLE_START_ROW + 1) / visibleRowsCount) * 100);
              const heightPct = Math.max(0, botY - topY);

              const clipId = `lock-piece-clip-${lockFlash.timestamp}`;

              // Find bottom contact cells for each column of the locked piece
              const colBottoms = new Map<number, number>();
              for (const pt of lockFlash.cells) {
                const cur = colBottoms.get(pt.x);
                if (cur === undefined || pt.y > cur) {
                  colBottoms.set(pt.x, pt.y);
                }
              }

              const bottomPoints: { x: number; y: number }[] = [];
              const sortedCols = Array.from(colBottoms.keys()).sort((a, b) => a - b);
              sortedCols.forEach((col) => {
                bottomPoints.push({
                  x: col,
                  y: colBottoms.get(col)!,
                });
              });

              return (
                <>
                  {/* SVG clip-path matching ONLY the exact tetromino cells */}
                  <svg
                    className="absolute w-0 h-0 pointer-events-none"
                    style={{ position: 'absolute', width: 0, height: 0 }}
                  >
                    <defs>
                      <clipPath id={clipId} clipPathUnits="objectBoundingBox">
                        {lockFlash.cells.map((pt, cIdx) => {
                          const vr = pt.y - VISIBLE_START_ROW;
                          if (vr < 0 || vr >= visibleRowsCount) return null;
                          return (
                            <rect
                              key={`lock-clip-rect-${cIdx}`}
                              x={pt.x / 10}
                              y={vr / 20}
                              width={1 / 10}
                              height={1 / 20}
                            />
                          );
                        })}
                      </clipPath>
                    </defs>
                  </svg>

                  {/* Lock light: normal locks get the top-to-bottom cascade; spin locks get a piece-shaped flash instead */}
                  <div
                    className="absolute inset-0 pointer-events-none overflow-hidden"
                    style={{ clipPath: `url(#${clipId})` }}
                  >
                    <div
                      className="absolute pointer-events-none overflow-hidden"
                      style={{
                        left: `${startX}%`,
                        width: `${widthPct}%`,
                        top: `${topY}%`,
                        height: `${heightPct}%`,
                      }}
                    >
                      {(!lockFlash.isSpin || !impactParticlesEnabled) && (
                        <div
                          className="absolute inset-x-0 h-[12px] animate-lock-cascade-down pointer-events-none flex flex-col justify-end"
                          style={{
                            background:
                              'linear-gradient(to bottom, transparent 0%, rgba(255, 255, 255, 0.25) 30%, rgba(255, 255, 255, 0.95) 80%, #ffffff 100%)',
                            boxShadow: '0 0 16px rgba(255, 255, 255, 0.95), 0 0 32px rgba(255, 255, 255, 0.6)',
                          }}
                        >
                          <div className="w-full h-[2.5px] bg-white rounded-full shadow-[0_0_8px_#ffffff]" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Spin lock: the piece flashes white and cools into its own color, with a soft glow around its exact shape */}
                  {impactParticlesEnabled && lockFlash.isSpin && (
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{
                        filter: `drop-shadow(0 0 6px rgba(255, 255, 255, 0.95)) drop-shadow(0 0 16px ${palette[lockFlash.type]?.solid || '#ffffff'})`,
                      }}
                    >
                      <div
                        className="absolute inset-0 animate-spin-flash"
                        style={{
                          clipPath: `url(#${clipId})`,
                          backgroundColor: '#ffffff',
                          '--spin-color': palette[lockFlash.type]?.solid || '#ffffff',
                        } as React.CSSProperties}
                      />
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        )}

        {/* Hard Drop Trail Light: Unified luminous ribbon across full piece drop footprint */}
        {impactParticlesEnabled && hardDropTrail && !isPaused && hardDropTrail.startY < hardDropTrail.endY && (
          <div
            key={`trail-wrapper-${hardDropTrail.timestamp}`}
            className="absolute inset-0 pointer-events-none z-20 overflow-hidden"
          >
            {(() => {
              const trailColor = palette[hardDropTrail.type].solid;
              const leftPercent = hardDropTrail.startCol * 10;
              const widthPercent = hardDropTrail.spanCols * 10;
              const topPercent = Math.max(
                0,
                ((hardDropTrail.startY - VISIBLE_START_ROW) / visibleRowsCount) * 100
              );
              const bottomPercent =
                ((hardDropTrail.endY - VISIBLE_START_ROW + 1) / visibleRowsCount) * 100;
              const heightPercent = Math.max(0, bottomPercent - topPercent);

              if (heightPercent <= 0) return null;

              return (
                <div
                  key={`trail-anim-${hardDropTrail.timestamp}`}
                  className="absolute animate-drop-trail-fast flex items-center justify-center pointer-events-none"
                  style={{
                    left: `${leftPercent}%`,
                    width: `${widthPercent}%`,
                    top: `${topPercent}%`,
                    height: `${heightPercent}%`,
                    background: `linear-gradient(to bottom, transparent 0%, rgba(255, 255, 255, 0.25) 15%, ${trailColor}45 80%, transparent 100%)`,
                  }}
                >
                  {/* Left edge laser */}
                  <div
                    className="absolute left-0 top-0 bottom-0 w-[1.5px]"
                    style={{
                      background: '#ffffff',
                      boxShadow: `0 0 8px #ffffff, 0 0 12px ${trailColor}`,
                    }}
                  />
                  {/* Right edge laser */}
                  <div
                    className="absolute right-0 top-0 bottom-0 w-[1.5px]"
                    style={{
                      background: '#ffffff',
                      boxShadow: `0 0 8px #ffffff, 0 0 12px ${trailColor}`,
                    }}
                  />
                </div>
              );
            })()}
          </div>
        )}

        {/* Hard Drop Landing Impact Effect: Solid unified downward shift strictly along vertical axis (Zero sand / zero lateral scatter) */}
        {impactParticlesEnabled && hardDropImpact && !isPaused && (
          <div className="absolute inset-0 pointer-events-none z-25 overflow-hidden">
            {(() => {
              const impactColor = palette[hardDropImpact.type].solid;

              return hardDropImpact.spans.map((span, idx) => {
                const yPercent = Math.min(
                  100,
                  ((span.bottomY - VISIBLE_START_ROW) / visibleRowsCount) * 100
                );
                const leftPercent = span.startCol * 10;
                const widthPercent = span.spanCols * 10;

                return (
                  <div
                    key={`impact-span-${span.startCol}-${span.bottomY}-${idx}`}
                    className="absolute pointer-events-none animate-hard-drop-shift-down flex flex-col items-center"
                    style={{
                      left: `${leftPercent}%`,
                      width: `${widthPercent}%`,
                      top: `${yPercent}%`,
                    }}
                  >
                    {/* Solid horizontal impact stamp line strictly shifting downwards */}
                    <div
                      className="w-full h-[2.5px]"
                      style={{
                        background: '#ffffff',
                        boxShadow: `0 0 8px #ffffff, 0 0 16px ${impactColor}`,
                      }}
                    />
                    {/* Vertical downward light veil shifting strictly down into the floor */}
                    <div
                      className="w-full h-[14px] animate-hard-drop-curtain-down"
                      style={{
                        background: `linear-gradient(to bottom, rgba(255, 255, 255, 0.75) 0%, ${impactColor}50 40%, transparent 100%)`,
                      }}
                    />
                  </div>
                );
              });
            })()}
          </div>
        )}

        {/* CLEAN NON-SANDY LINE CLEAR EFFECTS: Horizontal Laser Blade & Aperture Sweeps */}
        {lineClearEffectsEnabled && clearingBands.length > 0 && !isPaused && (
          <div className="absolute inset-0 pointer-events-none z-30 overflow-visible">
            {clearingBands.map((band, bandIdx) => {
              const topPercent = ((band.startRow - VISIBLE_START_ROW) / visibleRowsCount) * 100;
              const heightPercent = (band.rowCount / visibleRowsCount) * 100;

              // CASE 1: Single Line Clear (Non-sandy Laser Blade & Horizontal Sweep)
              if (band.rowCount === 1) {
                return (
                  <div
                    key={`mono-clear-single-${bandIdx}`}
                    className="absolute inset-x-0 h-[5%] flex items-center justify-center pointer-events-none overflow-hidden"
                    style={{
                      top: `${topPercent}%`,
                    }}
                  >
                    {/* Sleek horizontal luminous aperture wash across the entire clearing row */}
                    <div
                      className="absolute inset-0 bg-white/30 animate-line-aperture-flash"
                      style={{
                        boxShadow: '0 0 16px rgba(255, 255, 255, 0.8), 0 0 32px rgba(255, 255, 255, 0.4)',
                      }}
                    />
                    {/* Razor-sharp central horizontal laser blade */}
                    <div
                      className="w-full h-[2.5px] bg-white animate-line-laser-blade"
                      style={{
                        boxShadow: '0 0 10px #ffffff, 0 0 20px #ffffff, 0 0 30px rgba(255, 255, 255, 0.9)',
                      }}
                    />
                    {/* Left horizontal laser sweep blade */}
                    <div
                      className="absolute left-0 w-1/2 h-[1.5px] bg-white animate-line-laser-sweep-left"
                      style={{
                        boxShadow: '0 0 8px #ffffff',
                      }}
                    />
                    {/* Right horizontal laser sweep blade */}
                    <div
                      className="absolute right-0 w-1/2 h-[1.5px] bg-white animate-line-laser-sweep-right"
                      style={{
                        boxShadow: '0 0 8px #ffffff',
                      }}
                    />
                  </div>
                );
              }

              // CASE 2: Multi-Line Clears (Double, Triple, Tetris) - Geometric Laser Blades & Horizontal Scanlines
              return (
                <div
                  key={`mono-clear-multi-${bandIdx}`}
                  className="absolute inset-x-0 pointer-events-none flex flex-col justify-between overflow-hidden"
                  style={{
                    top: `${topPercent}%`,
                    height: `${heightPercent}%`,
                  }}
                >
                  {/* Top razor-sharp laser blade */}
                  <div
                    className="w-full h-[2px] bg-white animate-line-laser-blade"
                    style={{
                      boxShadow: '0 0 10px #ffffff, 0 0 20px rgba(255, 255, 255, 0.85)',
                    }}
                  />

                  {/* Unified interior ambient laser beam wash */}
                  <div
                    className="w-full flex-1 relative flex items-center justify-center animate-line-aperture-flash"
                    style={{
                      background:
                        'linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.12) 15%, rgba(255, 255, 255, 0.4) 50%, rgba(255, 255, 255, 0.12) 85%, transparent 100%)',
                    }}
                  >
                    {/* Central horizontal laser beam */}
                    <div
                      className="w-full h-[2px] bg-white animate-line-laser-blade"
                      style={{
                        boxShadow: '0 0 12px #ffffff, 0 0 24px rgba(255, 255, 255, 0.9)',
                      }}
                    />
                    {/* Left horizontal laser sweep */}
                    <div
                      className="absolute left-0 w-1/2 h-[1.5px] bg-white animate-line-laser-sweep-left"
                      style={{
                        boxShadow: '0 0 8px #ffffff',
                      }}
                    />
                    {/* Right horizontal laser sweep */}
                    <div
                      className="absolute right-0 w-1/2 h-[1.5px] bg-white animate-line-laser-sweep-right"
                      style={{
                        boxShadow: '0 0 8px #ffffff',
                      }}
                    />
                  </div>

                  {/* Bottom razor-sharp laser blade */}
                  <div
                    className="w-full h-[2px] bg-white animate-line-laser-blade"
                    style={{
                      boxShadow: '0 0 10px #ffffff, 0 0 20px rgba(255, 255, 255, 0.85)',
                    }}
                  />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
});

TetrisBoard.displayName = 'TetrisBoard';

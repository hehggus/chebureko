import React, { useEffect, useRef } from 'react';

interface LevelStepperProps {
  level: number;
  min?: number;
  max?: number;
  onChange: (level: number) => void;
  label?: string;
}

const Triangle: React.FC<{ direction: 'left' | 'right' }> = ({ direction }) => (
  <svg
    viewBox="0 0 8 10"
    aria-hidden="true"
    className={`w-2 h-2.5 fill-current ${direction === 'right' ? 'rotate-180' : ''}`}
  >
    <path d="M7.5 0.5 L0.5 5 L7.5 9.5 Z" />
  </svg>
);

/**
 * Compact Marathon starting-level control used inside the Marathon mode card:
 * a small LEVEL caption above a triangular prev / value / next pill.
 */
export const LevelStepper: React.FC<LevelStepperProps> = ({
  level,
  min = 1,
  max = 15,
  onChange,
  label = 'LEVEL',
}) => {
  // Keep a local mirror of the level so that rapid clicks always advance
  // from the latest value instead of the (possibly stale) prop.
  const levelRef = useRef(level);
  useEffect(() => {
    levelRef.current = level;
  }, [level]);

  const clamp = (value: number) => Math.max(min, Math.min(max, value));

  const step = (delta: number) => {
    const next = clamp(levelRef.current + delta);
    levelRef.current = next;
    onChange(next);
  };

  const clamped = clamp(level);
  const canDecrease = clamped > min;
  const canIncrease = clamped < max;

  const arrowClass = (enabled: boolean) =>
    `w-5 h-5 rounded flex items-center justify-center transition-all ${
      enabled
        ? 'text-zinc-300 hover:bg-white/[0.10] hover:text-white active:scale-90 cursor-pointer'
        : 'text-zinc-700 cursor-not-allowed'
    }`;

  return (
    <div className="flex flex-col items-end gap-1 flex-shrink-0">
      <span className="text-[8px] font-mono uppercase tracking-wider text-zinc-500 leading-none">
        {label}
      </span>
      <div className="flex items-center gap-0.5 rounded-md bg-black/40 border border-white/[0.10] p-0.5">
        <button
          type="button"
          aria-label="Previous level"
          disabled={!canDecrease}
          onClick={() => step(-1)}
          className={arrowClass(canDecrease)}
        >
          <Triangle direction="left" />
        </button>
        <span className="w-6 text-center font-mono text-xs font-bold text-white tabular-nums">
          {clamped}
        </span>
        <button
          type="button"
          aria-label="Next level"
          disabled={!canIncrease}
          onClick={() => step(1)}
          className={arrowClass(canIncrease)}
        >
          <Triangle direction="right" />
        </button>
      </div>
    </div>
  );
};

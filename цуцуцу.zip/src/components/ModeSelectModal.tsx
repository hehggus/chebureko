import React, { useState, useEffect } from 'react';
import type { GameMode, Language } from '../game/types.ts';
import { Play, Zap, Flame, Clock, Sparkles, Trophy } from 'lucide-react';
import { TRANSLATIONS } from '../game/i18n.ts';
import { formatTime } from '../game/rules.ts';
import { getHighScores } from '../utils/highScores.ts';
import type { HighScoreEntry } from '../utils/highScores.ts';
import { LevelStepper } from './LevelStepper.tsx';

interface ModeSelectModalProps {
  isOpen: boolean;
  selectedMode: GameMode;
  language?: Language;
  onSelectAndStart: (mode: GameMode, startLevel: number) => void;
}

export const ModeSelectModal: React.FC<ModeSelectModalProps> = ({
  isOpen,
  selectedMode,
  language = 'en',
  onSelectAndStart,
}) => {
  const [activeMode, setActiveMode] = useState<GameMode>(selectedMode);
  // Guideline 2.3.3 / Section 6: Marathon starting level (1-15, default 1)
  const [startLevel, setStartLevel] = useState(1);
  // Guideline 11.2: High Score table for the highlighted mode
  const [scores, setScores] = useState<HighScoreEntry[]>(() => getHighScores(selectedMode));
  const t = TRANSLATIONS[language];

  useEffect(() => {
    setScores(getHighScores(activeMode));
  }, [activeMode, isOpen]);

  if (!isOpen) return null;

  const modes: {
    id: GameMode;
    title: string;
    desc: string;
    badge: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'marathon',
      title: t.modes.marathon.name.toUpperCase(),
      desc: t.modes.marathon.desc,
      badge: 'CLASSIC',
      icon: <Flame className="w-4 h-4 text-zinc-200" />,
    },
    {
      id: 'sprint',
      title: t.modes.sprint.name.toUpperCase(),
      desc: t.modes.sprint.desc,
      badge: 'SPEED',
      icon: <Zap className="w-4 h-4 text-zinc-200" />,
    },
    {
      id: 'ultra',
      title: t.modes.ultra.name.toUpperCase(),
      desc: t.modes.ultra.desc,
      badge: 'TIMER',
      icon: <Clock className="w-4 h-4 text-zinc-200" />,
    },
    {
      id: 'freeplay',
      title: t.modes.freeplay.name.toUpperCase(),
      desc: t.modes.freeplay.desc,
      badge: 'FREE',
      icon: <Sparkles className="w-4 h-4 text-zinc-200" />,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="bg-[#18181c] border border-zinc-700/60 rounded-lg w-full max-w-sm p-4 sm:p-5 shadow-2xl text-zinc-200 font-sans flex flex-col max-h-[85vh]">
        {/* Title */}
        <div className="text-center mb-3">
          <h2 className="text-base font-bold font-mono tracking-wider text-white uppercase">
            {t.chooseMode}
          </h2>
          <p className="text-[11px] text-zinc-500 font-mono mt-0.5">
            Select your game rules
          </p>
        </div>

        {/* Scrollable content */}
        <div className="overflow-y-auto pr-0.5 -mr-0.5 flex-1 min-h-0">
          {/* Mode cards list */}
          <div className="space-y-1 mb-3.5">
            {modes.map((m) => {
              const isSelected = activeMode === m.id;
              return (
                <div
                  key={m.id}
                  className={`w-full p-2 rounded-md border transition-all flex items-center gap-2 ${
                    isSelected
                      ? 'bg-white/[0.08] border-white/25 text-white'
                      : 'bg-white/[0.02] border-white/[0.05] hover:bg-white/[0.05] text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setActiveMode(m.id)}
                    className="flex-1 min-w-0 flex items-center gap-2.5 text-left cursor-pointer"
                  >
                    <div
                      className={`p-1.5 rounded-md flex-shrink-0 ${
                        isSelected ? 'bg-white/[0.1] text-white' : 'bg-white/[0.04] text-zinc-400'
                      }`}
                    >
                      {m.icon}
                    </div>
                    <div className="flex-1 min-w-0 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="font-mono font-bold text-xs block truncate">
                          {m.title}
                        </span>
                        <span className="text-[10px] text-zinc-500 font-mono block truncate">
                          {m.desc}
                        </span>
                      </div>
                      {m.id !== 'marathon' && (
                        <span
                          className={`text-[9px] font-mono px-1.5 py-0.5 rounded flex-shrink-0 ${
                            isSelected
                              ? 'bg-white text-zinc-950 font-bold'
                              : 'bg-white/[0.05] text-zinc-400'
                          }`}
                        >
                          {m.badge}
                        </span>
                      )}
                    </div>
                  </button>
                  {m.id === 'marathon' && (
                    <LevelStepper
                      level={startLevel}
                      onChange={(lvl) => {
                        setStartLevel(lvl);
                        setActiveMode('marathon');
                      }}
                      label={t.level}
                    />
                  )}
                </div>
              );
            })}
          </div>

          {/* High Score table (Guideline 11.2) */}
          <div className="mb-3.5">
            <div className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 mb-1.5 flex items-center gap-1.5">
              <Trophy className="w-3 h-3" />
              {t.highScores}
            </div>
            {scores.length === 0 ? (
              <div className="text-[10px] font-mono text-zinc-600 py-2 text-center bg-white/[0.02] rounded-md border border-white/[0.05]">
                {t.noHighScores}
              </div>
            ) : (
              <div className="bg-white/[0.02] border border-white/[0.05] rounded-md overflow-hidden">
                <table className="w-full font-mono text-[10px]">
                  <thead>
                    <tr className="text-zinc-500 border-b border-white/[0.05]">
                      <th className="py-1 pl-2 text-left font-medium">#</th>
                      <th className="py-1 text-right font-medium">{t.score}</th>
                      <th className="py-1 text-right font-medium">{t.lines}</th>
                      <th className="py-1 text-right font-medium">{t.level}</th>
                      <th className="py-1 pr-2 text-right font-medium">{t.time}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scores.map((entry, i) => (
                      <tr key={i} className="border-b border-white/[0.03] last:border-0">
                        <td className="py-1 pl-2 text-left text-zinc-500">{i + 1}</td>
                        <td className="py-1 text-right text-white font-bold">
                          {entry.score.toLocaleString()}
                        </td>
                        <td className="py-1 text-right text-zinc-300">{entry.lines}</td>
                        <td className="py-1 text-right text-zinc-400">{entry.level}</td>
                        <td className="py-1 pr-2 text-right text-zinc-400">
                          {formatTime(entry.timeMs)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Start Button */}
        <button
          type="button"
          onClick={() => onSelectAndStart(activeMode, activeMode === 'marathon' ? startLevel : 1)}
          className="w-full py-2.5 rounded-md bg-white hover:bg-zinc-200 active:bg-zinc-300 text-zinc-950 font-bold text-xs uppercase tracking-wider font-mono flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer mt-1 flex-shrink-0"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          {t.startGame}
        </button>
      </div>
    </div>
  );
};

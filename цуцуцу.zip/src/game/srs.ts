import type { PieceType, RotationState } from './types.ts';

// Super Rotation System (SRS) Wall Kick Offsets
// Coordinates in (x, y) where x increases right, and y increases DOWN.
// When guideline says +1 Y (up), in our inverted board coordinates that is -1 Y.

type RotationTransition = `${RotationState}->${RotationState}`;

// Standard 3x3 pieces: J, L, S, T, Z
const JLSTZ_KICKS: Partial<Record<RotationTransition, [number, number][]>> = {
  // CW
  '0->1': [[0, 0], [-1, 0], [-1, -1], [0, 2], [-1, 2]],
  '1->2': [[0, 0], [1, 0], [1, 1], [0, -2], [1, -2]],
  '2->3': [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]],
  '3->0': [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]],

  // CCW
  '1->0': [[0, 0], [1, 0], [1, 1], [0, -2], [1, -2]],
  '2->1': [[0, 0], [-1, 0], [-1, -1], [0, 2], [-1, 2]],
  '3->2': [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]],
  '0->3': [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]],

  // 180° Kicks (Tetr.js / Jstris standard 180 table)
  '0->2': [[0, 0], [0, -1], [1, -1], [-1, -1], [1, 0], [-1, 0]],
  '2->0': [[0, 0], [0, 1], [-1, 1], [1, 1], [-1, 0], [1, 0]],
  '1->3': [[0, 0], [1, 0], [1, -2], [1, -1], [0, -2], [0, -1]],
  '3->1': [[0, 0], [-1, 0], [-1, -2], [-1, -1], [0, -2], [0, -1]],
};

// I Tetrimino 4x4 bounding box kicks
const I_KICKS: Partial<Record<RotationTransition, [number, number][]>> = {
  // CW
  '0->1': [[0, 0], [-2, 0], [1, 0], [-2, 1], [1, -2]],
  '1->2': [[0, 0], [-1, 0], [2, 0], [-1, -2], [2, 1]],
  '2->3': [[0, 0], [2, 0], [-1, 0], [2, -1], [-1, 2]],
  '3->0': [[0, 0], [1, 0], [-2, 0], [1, 2], [-2, -1]],

  // CCW
  '1->0': [[0, 0], [2, 0], [-1, 0], [2, -1], [-1, 2]],
  '2->1': [[0, 0], [1, 0], [-2, 0], [1, 2], [-2, -1]],
  '3->2': [[0, 0], [-2, 0], [1, 0], [-2, 1], [1, -2]],
  '0->3': [[0, 0], [-1, 0], [2, 0], [-1, -2], [2, 1]],

  // 180° Kicks for I piece
  '0->2': [[0, 0], [-1, 0], [1, 0], [0, -1], [0, 1]],
  '2->0': [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]],
  '1->3': [[0, 0], [0, -1], [0, 1], [-1, 0], [1, 0]],
  '3->1': [[0, 0], [0, 1], [0, -1], [1, 0], [-1, 0]],
};

export function getSRSKicks(
  pieceType: PieceType,
  fromState: RotationState,
  toState: RotationState
): [number, number][] {
  if (pieceType === 'O') {
    return [[0, 0]];
  }

  const key: RotationTransition = `${fromState}->${toState}`;
  if (pieceType === 'I') {
    return I_KICKS[key] || [[0, 0]];
  }

  return JLSTZ_KICKS[key] || [[0, 0]];
}

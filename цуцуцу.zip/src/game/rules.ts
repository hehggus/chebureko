import type {
  ActivePiece,
  BoardMatrix,
  GameMode,
  PieceType,
  RotationState,
  TSpinType,
} from './types.ts';
import {
  LEVEL_FALL_SPEEDS_MS,
  MATRIX_TOTAL_HEIGHT,
  MATRIX_WIDTH,
  PIECE_SHAPES,
  SPAWN_COORDINATES,
} from './constants.ts';
import { getSRSKicks } from './srs.ts';

export function createEmptyBoard(): BoardMatrix {
  return Array.from({ length: MATRIX_TOTAL_HEIGHT }, () =>
    Array(MATRIX_WIDTH).fill(null)
  );
}

export function generate7Bag(): PieceType[] {
  const pieces: PieceType[] = ['I', 'J', 'L', 'O', 'S', 'T', 'Z'];
  // Fisher-Yates shuffle
  for (let i = pieces.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pieces[i], pieces[j]] = [pieces[j], pieces[i]];
  }
  return pieces;
}

export function spawnPiece(type: PieceType): ActivePiece {
  const spawn = SPAWN_COORDINATES[type];
  return {
    type,
    rotation: 0,
    x: spawn.x,
    y: spawn.y,
    lowestY: spawn.y,
    lockMovesCount: 0,
  };
}

export function checkCollision(
  board: BoardMatrix,
  pieceType: PieceType,
  rotation: RotationState,
  px: number,
  py: number
): boolean {
  const shape = PIECE_SHAPES[pieceType][rotation];
  for (let r = 0; r < shape.length; r++) {
    for (let c = 0; c < shape[r].length; c++) {
      if (shape[r][c] !== 0) {
        const boardX = px + c;
        const boardY = py + r;

        // Check horizontal bounds
        if (boardX < 0 || boardX >= MATRIX_WIDTH) {
          return true;
        }

        // Check floor bound
        if (boardY >= MATRIX_TOTAL_HEIGHT) {
          return true;
        }

        // Check if inside board and collides with locked block
        if (boardY >= 0 && board[boardY][boardX] !== null) {
          return true;
        }
      }
    }
  }
  return false;
}

export function tryMovePiece(
  board: BoardMatrix,
  piece: ActivePiece,
  dx: number,
  dy: number
): { success: boolean; piece: ActivePiece } {
  const newX = piece.x + dx;
  const newY = piece.y + dy;

  if (!checkCollision(board, piece.type, piece.rotation, newX, newY)) {
    const isNewLowest = newY > piece.lowestY;
    return {
      success: true,
      piece: {
        ...piece,
        x: newX,
        y: newY,
        lowestY: Math.max(piece.lowestY, newY),
        lockMovesCount: isNewLowest ? 0 : piece.lockMovesCount + (dx !== 0 ? 1 : 0),
        hasUsedPoint5Kick: (dx !== 0 || dy > 0) ? false : piece.hasUsedPoint5Kick,
      },
    };
  }

  return { success: false, piece };
}

export function tryRotatePiece(
  board: BoardMatrix,
  piece: ActivePiece,
  direction: 'CW' | 'CCW' | '180'
): { success: boolean; piece: ActivePiece; kickIndex: number } {
  let targetRotation: RotationState;
  if (direction === 'CW') {
    targetRotation = ((piece.rotation + 1) % 4) as RotationState;
  } else if (direction === 'CCW') {
    targetRotation = ((piece.rotation + 3) % 4) as RotationState;
  } else {
    // 180°
    targetRotation = ((piece.rotation + 2) % 4) as RotationState;
  }

  const kicks = getSRSKicks(piece.type, piece.rotation, targetRotation);

  for (let i = 0; i < kicks.length; i++) {
    const [kickX, kickY] = kicks[i];
    const testX = piece.x + kickX;
    const testY = piece.y + kickY;

    if (!checkCollision(board, piece.type, targetRotation, testX, testY)) {
      const isNewLowest = testY > piece.lowestY;
      const isPoint5Kick = direction !== '180' && i === 4;

      return {
        success: true,
        piece: {
          ...piece,
          rotation: targetRotation,
          x: testX,
          y: testY,
          lowestY: Math.max(piece.lowestY, testY),
          lockMovesCount: isNewLowest ? 0 : piece.lockMovesCount + 1,
          // Guideline 9.1.1: "Rotation Point 5 is used to rotate the tetrimino into the
          // t-Slot. Any further rotation will be considered a t-Spin, not a Mini."
          // The flag is therefore sticky across rotations and only cleared by translation
          // (see tryMovePiece), never by a later kick-free rotation.
          hasUsedPoint5Kick:
            piece.type === 'T' && (piece.hasUsedPoint5Kick || isPoint5Kick),
        },
        kickIndex: i,
      };
    }
  }

  return { success: false, piece, kickIndex: -1 };
}

export function getGhostPieceY(board: BoardMatrix, piece: ActivePiece): number {
  let ghostY = piece.y;
  while (!checkCollision(board, piece.type, piece.rotation, piece.x, ghostY + 1)) {
    ghostY++;
  }
  return ghostY;
}

export function detectTSpin(
  board: BoardMatrix,
  piece: ActivePiece,
  lastActionWasRotation: boolean,
  kickIndex: number,
  is180Rotation: boolean = false
): TSpinType {
  if (piece.type !== 'T' || !lastActionWasRotation) {
    return 'none';
  }

  // T center in 3x3 is at (x + 1, y + 1)
  const centerX = piece.x + 1;
  const centerY = piece.y + 1;

  // 4 diagonally adjacent corners: NW, NE, SE, SW
  const corners = [
    { x: centerX - 1, y: centerY - 1 }, // NW (0)
    { x: centerX + 1, y: centerY - 1 }, // NE (1)
    { x: centerX + 1, y: centerY + 1 }, // SE (2)
    { x: centerX - 1, y: centerY + 1 }, // SW (3)
  ];

  const isOccupied = (pt: { x: number; y: number }) => {
    if (pt.x < 0 || pt.x >= MATRIX_WIDTH || pt.y >= MATRIX_TOTAL_HEIGHT) {
      return true; // Wall or floor counts as occupied surface
    }
    if (pt.y < 0) return false;
    return board[pt.y][pt.x] !== null;
  };

  const cornerStates = corners.map(isOccupied);
  const occupiedCorners = cornerStates.filter(Boolean).length;

  // Guideline 9.1: At least 3 of the 4 diagonally adjacent corners must be occupied
  if (occupiedCorners < 3) {
    return 'none';
  }

  // Determine front corners facing the T-stem:
  // Rotation 0 (North): front corners are NW (0) and NE (1)
  // Rotation 1 (East): front corners are NE (1) and SE (2)
  // Rotation 2 (South): front corners are SE (2) and SW (3)
  // Rotation 3 (West): front corners are SW (3) and NW (0)
  let frontA = 0;
  let frontB = 1;

  if (piece.rotation === 0) {
    frontA = 0;
    frontB = 1;
  } else if (piece.rotation === 1) {
    frontA = 1;
    frontB = 2;
  } else if (piece.rotation === 2) {
    frontA = 2;
    frontB = 3;
  } else if (piece.rotation === 3) {
    frontA = 3;
    frontB = 0;
  }

  const frontCornersFilled = cornerStates[frontA] && cornerStates[frontB];

  // Guideline 9.1.1: If 5th rotation test point (kickIndex 4) was used in a 90° rotation,
  // or if both front corners are occupied, or if Point 5 was previously used to enter the T-Slot,
  // it is recognized as a regular T-Spin.
  // Guideline 9.1.2: If only 1 front corner is occupied (and both rear corners are occupied),
  // and Point 5 was not used, it is recognized as a Mini T-Spin.
  if ((!is180Rotation && (kickIndex === 4 || piece.hasUsedPoint5Kick)) || frontCornersFilled) {
    return 'regular';
  }

  return 'mini';
}

export function lockPieceToBoard(board: BoardMatrix, piece: ActivePiece): BoardMatrix {
  const newBoard = board.map((row) => [...row]);
  const shape = PIECE_SHAPES[piece.type][piece.rotation];

  for (let r = 0; r < shape.length; r++) {
    for (let c = 0; c < shape[r].length; c++) {
      if (shape[r][c] !== 0) {
        const by = piece.y + r;
        const bx = piece.x + c;
        if (by >= 0 && by < MATRIX_TOTAL_HEIGHT && bx >= 0 && bx < MATRIX_WIDTH) {
          newBoard[by][bx] = piece.type;
        }
      }
    }
  }

  return newBoard;
}

export function checkAndClearLines(board: BoardMatrix): {
  newBoard: BoardMatrix;
  clearedRowIndices: number[];
  isAllClear: boolean;
} {
  const clearedRowIndices: number[] = [];

  for (let r = 0; r < MATRIX_TOTAL_HEIGHT; r++) {
    if (board[r].every((cell) => cell !== null)) {
      clearedRowIndices.push(r);
    }
  }

  if (clearedRowIndices.length === 0) {
    return { newBoard: board, clearedRowIndices, isAllClear: false };
  }

  // Filter out cleared rows and prepend new empty rows at the top
  const remainingRows = board.filter((_, idx) => !clearedRowIndices.includes(idx));
  const emptyRows = Array.from({ length: clearedRowIndices.length }, () =>
    Array(MATRIX_WIDTH).fill(null)
  );
  const newBoard = [...emptyRows, ...remainingRows];

  // Check if completely empty (Perfect Clear)
  const isAllClear = newBoard.every((row) => row.every((c) => c === null));

  return { newBoard, clearedRowIndices, isAllClear };
}

export function calculateScoring(
  linesCleared: number,
  tSpin: TSpinType,
  isCurrentB2B: boolean,
  combo: number,
  isAllClear: boolean,
  level: number
): { points: number; actionText: string; triggersB2B: boolean } {
  let basePoints = 0;
  let actionText = '';
  let triggersB2B = false;

  if (tSpin === 'regular') {
    if (linesCleared === 0) {
      basePoints = 400 * level;
      actionText = 'T-SPIN';
    } else if (linesCleared === 1) {
      basePoints = 800 * level;
      actionText = 'T-SPIN SINGLE';
      triggersB2B = true;
    } else if (linesCleared === 2) {
      basePoints = 1200 * level;
      actionText = 'T-SPIN DOUBLE';
      triggersB2B = true;
    } else if (linesCleared === 3) {
      basePoints = 1600 * level;
      actionText = 'T-SPIN TRIPLE';
      triggersB2B = true;
    }
  } else if (tSpin === 'mini') {
    if (linesCleared === 0) {
      basePoints = 100 * level;
      actionText = 'MINI T-SPIN';
    } else if (linesCleared === 1) {
      basePoints = 200 * level;
      actionText = 'MINI T-SPIN SINGLE';
      triggersB2B = true;
    } else if (linesCleared === 2) {
      basePoints = 400 * level;
      actionText = 'MINI T-SPIN DOUBLE';
      triggersB2B = true;
    }
  } else {
    // Normal line clears
    if (linesCleared === 1) {
      basePoints = 100 * level;
      actionText = 'SINGLE';
    } else if (linesCleared === 2) {
      basePoints = 300 * level;
      actionText = 'DOUBLE';
    } else if (linesCleared === 3) {
      basePoints = 500 * level;
      actionText = 'TRIPLE';
    } else if (linesCleared === 4) {
      basePoints = 800 * level;
      actionText = 'TETRIS!';
      triggersB2B = true;
    }
  }

  // Back-to-Back bonus: +50% of action value for consecutive Tetrises / T-spin line clears
  if (triggersB2B && isCurrentB2B) {
    basePoints = Math.floor(basePoints * 1.5);
    actionText = `B2B ${actionText}`;
  }

  // Combo bonus: 50 * combo * level
  if (combo > 0 && linesCleared > 0) {
    const comboPoints = 50 * combo * level;
    basePoints += comboPoints;
  }

  // Perfect Clear / All Clear
  if (isAllClear && linesCleared > 0) {
    let pcPoints = 0;
    if (linesCleared === 1) pcPoints = 800 * level;
    else if (linesCleared === 2) pcPoints = 1200 * level;
    else if (linesCleared === 3) pcPoints = 1800 * level;
    else if (linesCleared === 4) pcPoints = (isCurrentB2B ? 3200 : 2000) * level;
    basePoints += pcPoints;
    actionText = actionText ? `${actionText} + PERFECT CLEAR!` : 'PERFECT CLEAR!';
  }

  return { points: basePoints, actionText, triggersB2B };
}

export function getFallSpeed(level: number, mode: GameMode): number {
  if (mode === 'freeplay') return 1000;
  if (level >= 1 && level <= 15) {
    return LEVEL_FALL_SPEEDS_MS[level] || 1000;
  }
  // Formula from page 20: (0.8 - ((level - 1) * 0.007)) ^ (level - 1) seconds
  const l = Math.max(1, level);
  const base = Math.max(0.01, 0.8 - (l - 1) * 0.007);
  const seconds = Math.pow(base, l - 1);
  return Math.max(1, Math.round(seconds * 1000));
}

export function formatTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const centiseconds = Math.floor((ms % 1000) / 10);
  const mm = minutes.toString().padStart(2, '0');
  const ss = seconds.toString().padStart(2, '0');
  const cs = centiseconds.toString().padStart(2, '0');
  return `${mm}:${ss}.${cs}`;
}

// Guideline Section 6 (Fixed Goal System): 10 lines per level across 15 levels.
// The player may start at any level 1-15 ("the player must also have the option
// of starting from any level"), so both the level progression and the finish
// line count are offset by the chosen starting level.

export function getMarathonLevel(linesCleared: number, startLevel: number = 1): number {
  const start = Math.min(15, Math.max(1, Math.floor(startLevel)));
  return Math.min(15, Math.floor(Math.max(0, linesCleared) / 10) + start);
}

export function getMarathonTargetLines(startLevel: number = 1): number {
  const start = Math.min(15, Math.max(1, Math.floor(startLevel)));
  return (16 - start) * 10;
}

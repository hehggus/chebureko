export type PieceType = 'I' | 'J' | 'L' | 'O' | 'S' | 'T' | 'Z';
export type RotationState = 0 | 1 | 2 | 3; // 0 = North, 1 = East (90° CW), 2 = South (180°), 3 = West (270° CCW)

export interface MinoPosition {
  x: number;
  y: number;
}

export interface ActivePiece {
  type: PieceType;
  rotation: RotationState;
  x: number;
  y: number;
  lowestY: number; // for extended placement lock reset tracking (lowest row yet reached)
  lockMovesCount: number; // tracks up to 15 moves/rotations on surface
  hasUsedPoint5Kick?: boolean; // Guideline 9.1.1: Point 5 kick permanently flags T-Spin recognition
}

export type CellValue = PieceType | null;
export type BoardMatrix = CellValue[][]; // 40 rows high (0-19 buffer, 20-39 visible), 10 cols wide

export type GameMode = 'marathon' | 'sprint' | 'ultra' | 'freeplay';
export type GridStyle = 'checkerboard' | 'grid';
export type ColorPalette = 'pastel_neon' | 'vivid_guideline' | 'monochrome_gray';
export type GhostStyle = 'solid' | 'separated';
export type BlockSkin = 'solid' | 'lines';
export type GhostColor = 'colored' | 'gray';
export type Language = 'en';

export interface GameSettings {
  das: number; // Delayed Auto Shift (ms), default 300
  arr: number; // Auto Repeat Rate (ms), default 22 (0 = instant)
  sdf: number; // Soft Drop Factor: 20x, 40x, or 100 (instant)
  ghostPiece: boolean;
  ghostStyle: GhostStyle;
  ghostColor: GhostColor;
  blockSkin: BlockSkin;
  ghostOpacity: number; // 0.05 to 0.50
  gridOpacity: number; // 0.00 to 0.80 (supports down to 0%)
  ghostOutline: boolean; // toggle outline on ghost piece
  soundVolume: number; // 0 to 1
  musicVolume: number; // 0 to 1
  soundEnabled: boolean;
  musicEnabled: boolean;
  showWhiteOutline: boolean;
  whiteOutlineOpacity: number; // 0.00 to 1.00
  softPieceGlow: boolean; // Soft glow for white outline and ghost piece
  matrixShakeEnabled: boolean; // Screen shake effect toggle
  impactParticlesEnabled: boolean; // Hard drop trail/impact & spin flash effects toggle
  lockFlashEnabled: boolean; // Lock cascade / spin flash toggle
  lineClearEffectsEnabled: boolean; // Line clear laser/aperture effect toggle
  actionTextEnabled: boolean; // TETRIS / T-SPIN / combo / level-up text toggle
  gridStyle: GridStyle;
  colorPalette: ColorPalette;
  monochromeColor: string; // Unified color for monochrome palette
  language: Language;
}

export type TSpinType = 'none' | 'mini' | 'regular';

export interface LineClearResult {
  linesCleared: number;
  tSpin: TSpinType;
  isB2B: boolean;
  combo: number;
  isAllClear: boolean;
  pointsAwarded: number;
  actionText: string;
}

export interface GameStats {
  score: number;
  level: number;
  lines: number;
  pieces: number;
  tetrises: number;
  tspins: number;
  combos: number;
  maxCombo: number;
  b2bCount: number;
  timeElapsed: number; // in milliseconds
  remainingTime?: number; // for Ultra mode (ms)
}

export interface HardDropTrailData {
  startCol: number;
  spanCols: number;
  startY: number;
  endY: number;
  type: PieceType;
  timestamp: number;
}

export interface ContiguousImpactSpan {
  startCol: number;
  spanCols: number;
  bottomY: number;
}

export interface HardDropImpactData {
  spans: ContiguousImpactSpan[];
  type: PieceType;
  timestamp: number;
}

export interface LockFlashData {
  cells: { x: number; y: number }[];
  type: PieceType;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  isHardDrop: boolean;
  isSpin: boolean;
  spinType?: PieceType;
  spinDirection?: 'CW' | 'CCW' | '180' | null;
  timestamp: number;
}

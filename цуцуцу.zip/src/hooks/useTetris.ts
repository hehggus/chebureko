import { useState, useEffect, useRef, useCallback } from 'react';
import type {
  ActivePiece,
  BoardMatrix,
  GameMode,
  GameSettings,
  GameStats,
  HardDropTrailData,
  HardDropImpactData,
  ContiguousImpactSpan,
  LockFlashData,
  PieceType,
} from '../game/types.ts';
import {
  createEmptyBoard,
  generate7Bag,
  spawnPiece,
  tryMovePiece,
  tryRotatePiece,
  getGhostPieceY,
  detectTSpin,
  lockPieceToBoard,
  checkAndClearLines,
  calculateScoring,
  getFallSpeed,
  getMarathonLevel,
  getMarathonTargetLines,
  checkCollision,
} from '../game/rules.ts';
import { submitScore } from '../utils/highScores.ts';
import {
  LOCK_DELAY_MS,
  MAX_LOCK_MOVES,
  VISIBLE_START_ROW,
  PIECE_SHAPES,
} from '../game/constants.ts';
import { soundManager } from '../utils/audio.ts';

export const GUIDELINE_LINE_CLEAR_DELAY = 140; // Crisp arcade line clear animation delay (ms)

// Guideline A1.2.1: "the generation time of a tetrimino is 0.2 seconds after
// the Lock down of the previous tetrimino"
export const SPAWN_DELAY_MS = 200;

export const DEFAULT_SETTINGS: GameSettings = {
  // Guideline 5.2: auto-repeat delay "roughly 0.3 seconds", full board
  // crossing in "about 0.5 seconds" (300ms DAS + 9 x ~22ms ARR ≈ 500ms)
  das: 300,
  arr: 22,
  sdf: 20,
  ghostPiece: true,
  ghostStyle: "solid",
  ghostColor: "colored",
  blockSkin: "solid",
  ghostOpacity: 0.15,
  gridOpacity: 0.25,
  ghostOutline: true,
  soundVolume: 0.6,
  musicVolume: 0.3,
  soundEnabled: true,
  // Guideline 2.5.5: "the background music may be turned on or off.
  // The default must be set to on."
  musicEnabled: true,
  showWhiteOutline: true,
  whiteOutlineOpacity: 1,
  softPieceGlow: true,
  matrixShakeEnabled: true,
  impactParticlesEnabled: true,
  lockFlashEnabled: true,
  lineClearEffectsEnabled: true,
  actionTextEnabled: true,
  gridStyle: "checkerboard",
  colorPalette: "vivid_guideline",
  monochromeColor: "#f472b6",
  language: "en",
};

export interface ActionBanner {
  id: number;
  text: string;
  subText?: string;
  color?: string;
}

export function useTetris(initialMode: GameMode = 'marathon') {
  const [mode, setMode] = useState<GameMode>(initialMode);
  const [board, setBoard] = useState<BoardMatrix>(createEmptyBoard);
  const [activePiece, setActivePiece] = useState<ActivePiece | null>(null);
  const [ghostY, setGhostY] = useState<number>(0);
  const [holdPiece, setHoldPiece] = useState<PieceType | null>(null);
  const [canHold, setCanHold] = useState<boolean>(true);
  const [nextQueue, setNextQueue] = useState<PieceType[]>([]);
  const [, setBag] = useState<PieceType[]>([]);
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    level: 1,
    lines: 0,
    pieces: 0,
    tetrises: 0,
    tspins: 0,
    combos: 0,
    maxCombo: 0,
    b2bCount: 0,
    timeElapsed: 0,
    remainingTime: 120000,
  });
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isWon, setIsWon] = useState<boolean>(false);
  const [settings, setSettings] = useState<GameSettings>(DEFAULT_SETTINGS);
  const [actionBanners, setActionBanners] = useState<ActionBanner[]>([]);
  const [levelBanner, setLevelBanner] = useState<{ id: number; level: number } | null>(null);
  const [clearingRows, setClearingRows] = useState<number[]>([]);
  const [hardDropTrail, setHardDropTrail] = useState<HardDropTrailData | null>(null);
  const [hardDropImpact, setHardDropImpact] = useState<HardDropImpactData | null>(null);
  const [matrixShake, setMatrixShake] = useState<'drop' | 'bump-left' | 'bump-right' | null>(null);
  const [lockFlash, setLockFlash] = useState<LockFlashData | null>(null);

  // High-performance mutable state container for the game loop & physics
  const stateRef = useRef({
    board: createEmptyBoard(),
    activePiece: null as ActivePiece | null,
    holdPiece: null as PieceType | null,
    canHold: true,
    nextQueue: [] as PieceType[],
    bag: [] as PieceType[],
    stats: {
      score: 0,
      level: 1,
      lines: 0,
      pieces: 0,
      tetrises: 0,
      tspins: 0,
      combos: 0,
      maxCombo: 0,
      b2bCount: 0,
      timeElapsed: 0,
      remainingTime: 120000,
    } as GameStats,
    isPaused: false,
    isGameOver: false,
    isWon: false,
    mode: initialMode,
    startLevel: 1,
    pendingSpawn: false,
    spawnDelayTimer: 0,
    settings: DEFAULT_SETTINGS,
    lastActionWasRotation: false,
    lastKickIndex: 0,
    lastRotationWas180: false,
    lastRotationDirection: null as 'CW' | 'CCW' | '180' | null,
    isB2BActive: false,
    currentCombo: -1,
    lockTimer: 0,
    isGrounded: false,
    gravityAccumulator: 0,
    lastFrameTime: performance.now(),
    bufferedRotate: null as ('CW' | 'CCW' | '180') | null,
    bufferedHold: false,
    bufferedMove: null as -1 | 1 | null,
    bufferedSoftDrop: false,
    bufferedHardDrop: false,
    isSpawning: false,
    hasBumpedLeft: false,
    hasBumpedRight: false,
  });

  useEffect(() => {
    stateRef.current.settings = settings;
    soundManager.setSoundEnabled(settings.soundEnabled);
    soundManager.setMusicEnabled(settings.musicEnabled);
    soundManager.setSoundVolume(settings.soundVolume);
    soundManager.setMusicVolume(settings.musicVolume);
  }, [settings]);

  // Guideline Section 11.2: submit the final result to the High Score table
  // when the game ends (Game Over or Marathon/Sprint/Ultra completion).
  useEffect(() => {
    if (isGameOver || isWon) {
      const s = stateRef.current;
      submitScore(s.mode, {
        score: s.stats.score,
        lines: s.stats.lines,
        level: s.stats.level,
        timeMs: s.stats.timeElapsed,
        date: Date.now(),
      });
    }
  }, [isGameOver, isWon]);

  useEffect(() => {
    stateRef.current.mode = mode;
  }, [mode]);

  const showBanner = useCallback((text: string, subText?: string, color?: string) => {
    const bannerId = Date.now();
    setActionBanners((prev) => [...prev.slice(-1), { id: bannerId, text, subText, color }]);
    setTimeout(() => {
      setActionBanners((prev) => prev.filter((b) => b.id !== bannerId));
    }, 1100);
  }, []);

  const ensureQueue = useCallback((currentBag: PieceType[], currentQueue: PieceType[]) => {
    let newBag = [...currentBag];
    const newQueue = [...currentQueue];
    while (newQueue.length < 6) {
      if (newBag.length === 0) {
        newBag = generate7Bag();
      }
      const nextP = newBag.shift()!;
      newQueue.push(nextP);
    }
    return { newBag, newQueue };
  }, []);

  // Forward declarations for IRS/IHS
  const rotateCWRef = useRef<() => void>(() => {});
  const rotateCCWRef = useRef<() => void>(() => {});
  const rotate180Ref = useRef<() => void>(() => {});
  const holdRef = useRef<() => void>(() => {});
  const lineClearTimeoutRef = useRef<any>(null);
  const hardDropTrailTimeoutRef = useRef<any>(null);
  const hardDropImpactTimeoutRef = useRef<any>(null);

  const spawnNext = useCallback(() => {
    const s = stateRef.current;
    if (s.isGameOver || s.isWon) return;

    let { newBag, newQueue } = ensureQueue(s.bag, s.nextQueue);
    const nextType = newQueue.shift()!;
    const refilled = ensureQueue(newBag, newQueue);
    newBag = refilled.newBag;
    newQueue = refilled.newQueue;

    const newPiece = spawnPiece(nextType);

    // Block Out condition (Guideline 10 & A1.2.1)
    if (checkCollision(s.board, newPiece.type, newPiece.rotation, newPiece.x, newPiece.y)) {
      s.isGameOver = true;
      setIsGameOver(true);
      soundManager.playGameOver();
      return;
    }

    // Guideline 3.4 & 10: Drops one row if unobstructed (from row 18 down to row 19)
    if (!checkCollision(s.board, newPiece.type, newPiece.rotation, newPiece.x, newPiece.y + 1)) {
      newPiece.y += 1;
      newPiece.lowestY = newPiece.y;
    }

    s.activePiece = newPiece;
    s.lastActionWasRotation = false;
    s.lastKickIndex = 0;
    s.lockTimer = 0;
    s.isGrounded = checkCollision(s.board, newPiece.type, newPiece.rotation, newPiece.x, newPiece.y + 1);
    s.bag = newBag;
    s.nextQueue = newQueue;
    s.isSpawning = false;

    setActivePiece({ ...newPiece });
    setNextQueue([...newQueue]);
    setBag([...newBag]);

    const gy = getGhostPieceY(s.board, newPiece);
    setGhostY(gy);

    // Movement buffered during the 0.2s generation phase applies immediately
    // on spawn, so fast left/right taps between pieces are never dropped
    if (s.bufferedMove !== null) {
      const dir = s.bufferedMove;
      s.bufferedMove = null;
      const moved = tryMovePiece(s.board, s.activePiece, dir, 0);
      if (moved.success) {
        s.activePiece = moved.piece;
        setActivePiece({ ...moved.piece });
        s.isGrounded = checkCollision(
          s.board,
          moved.piece.type,
          moved.piece.rotation,
          moved.piece.x,
          moved.piece.y + 1
        );
        setGhostY(getGhostPieceY(s.board, moved.piece));
      }
    }

    // Buffered soft drop during the generation phase: apply one downward step
    if (s.bufferedSoftDrop) {
      s.bufferedSoftDrop = false;
      const softOldLowest = s.activePiece.lowestY;
      const softRes = tryMovePiece(s.board, s.activePiece, 0, 1);
      if (softRes.success) {
        s.activePiece = softRes.piece;
        s.lastActionWasRotation = false;
        if (softRes.piece.y > softOldLowest && softRes.piece.lockMovesCount <= MAX_LOCK_MOVES) {
          s.lockTimer = 0;
        }
        setActivePiece({ ...softRes.piece });
        s.isGrounded = checkCollision(
          s.board,
          softRes.piece.type,
          softRes.piece.rotation,
          softRes.piece.x,
          softRes.piece.y + 1
        );
        setGhostY(getGhostPieceY(s.board, softRes.piece));
      }
    }

    // Buffered hard drop during the generation phase: instant lock on spawn
    if (s.bufferedHardDrop) {
      s.bufferedHardDrop = false;
      const gy = getGhostPieceY(s.board, s.activePiece);
      s.activePiece.y = gy;
      s.isGrounded = true;
      soundManager.playHardDrop();
      lockActivePiece(true);
      return;
    }

    // Guideline IRS & IHS (Initial Rotation & Hold System)
    if (s.bufferedHold && s.canHold) {
      s.bufferedHold = false;
      s.bufferedRotate = null;
      holdRef.current();
      return;
    }
    if (s.bufferedRotate) {
      const rot = s.bufferedRotate;
      s.bufferedRotate = null;
      if (rot === 'CW') rotateCWRef.current();
      else if (rot === 'CCW') rotateCCWRef.current();
      else if (rot === '180') rotate180Ref.current();
    }
  }, [ensureQueue]);

  const startNewGame = useCallback((newMode: GameMode = mode, newStartLevel: number = 1) => {
    // Guideline Section 6 & 2.3.3: Marathon starts at the player-chosen level
    // (1-15, default 1); Sprint/Ultra/Freeplay always start at level 1.
    const appliedLevel =
      newMode === 'marathon' ? Math.min(15, Math.max(1, Math.floor(newStartLevel))) : 1;

    const emptyBoard = createEmptyBoard();
    const initialBag = generate7Bag();
    const queue = initialBag.splice(0, 6);
    const firstPieceType = queue.shift()!;
    if (initialBag.length === 0) {
      initialBag.push(...generate7Bag());
    }
    queue.push(initialBag.shift()!);

    const firstPiece = spawnPiece(firstPieceType);
    if (!checkCollision(emptyBoard, firstPiece.type, firstPiece.rotation, firstPiece.x, firstPiece.y + 1)) {
      firstPiece.y += 1;
      firstPiece.lowestY = firstPiece.y;
    }

    const initStats: GameStats = {
      score: 0,
      level: appliedLevel,
      lines: 0,
      pieces: 0,
      tetrises: 0,
      tspins: 0,
      combos: 0,
      maxCombo: 0,
      b2bCount: 0,
      timeElapsed: 0,
      remainingTime: newMode === 'ultra' ? 120000 : undefined,
    };

    stateRef.current = {
      ...stateRef.current,
      board: emptyBoard,
      activePiece: firstPiece,
      holdPiece: null,
      canHold: true,
      nextQueue: queue,
      bag: initialBag,
      stats: initStats,
      isPaused: false,
      isGameOver: false,
      isWon: false,
      mode: newMode,
      startLevel: appliedLevel,
      pendingSpawn: false,
      spawnDelayTimer: 0,
      lastActionWasRotation: false,
      lastKickIndex: 0,
      lastRotationDirection: null,
      isB2BActive: false,
      currentCombo: -1,
      lockTimer: 0,
      isGrounded: checkCollision(emptyBoard, firstPiece.type, firstPiece.rotation, firstPiece.x, firstPiece.y + 1),
      gravityAccumulator: 0,
      lastFrameTime: performance.now(),
      bufferedRotate: null,
      bufferedHold: false,
      bufferedMove: null,
      bufferedSoftDrop: false,
      bufferedHardDrop: false,
      isSpawning: false,
    };

    setMode(newMode);
    setBoard(emptyBoard);
    setActivePiece({ ...firstPiece });
    setHoldPiece(null);
    setCanHold(true);
    setNextQueue([...queue]);
    setBag([...initialBag]);
    setStats(initStats);
    setIsPaused(false);
    setIsGameOver(false);
    setIsWon(false);

    if (lineClearTimeoutRef.current) {
      clearTimeout(lineClearTimeoutRef.current);
      lineClearTimeoutRef.current = null;
    }
    if (hardDropTrailTimeoutRef.current) {
      clearTimeout(hardDropTrailTimeoutRef.current);
      hardDropTrailTimeoutRef.current = null;
    }
    if (hardDropImpactTimeoutRef.current) {
      clearTimeout(hardDropImpactTimeoutRef.current);
      hardDropImpactTimeoutRef.current = null;
    }
    setActionBanners([]);
    setLevelBanner(null);
    setClearingRows([]);
    setHardDropTrail(null);
    setHardDropImpact(null);
    setLockFlash(null);

    const gy = getGhostPieceY(emptyBoard, firstPiece);
    setGhostY(gy);
  }, [mode]);

  const lockActivePiece = useCallback((isFromHardDrop: boolean = false) => {
    const s = stateRef.current;
    const piece = s.activePiece;
    if (!piece || s.isGameOver || s.isWon) return;

    soundManager.playLock();

    // Lock Out check: must have at least one mino in visible rows (>= VISIBLE_START_ROW)
    let hasVisibleMino = false;
    const shape = PIECE_SHAPES[piece.type][piece.rotation];
    const lockedCells: { x: number; y: number }[] = [];

    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c] !== 0) {
          const by = piece.y + r;
          const bx = piece.x + c;
          lockedCells.push({ x: bx, y: by });
          if (by >= VISIBLE_START_ROW) {
            hasVisibleMino = true;
          }
        }
      }
    }

    if (!hasVisibleMino) {
      s.isGameOver = true;
      setIsGameOver(true);
      soundManager.playGameOver();
      return;
    }

    let minX = 999, maxX = -999, minY = 999, maxY = -999;
    for (const cell of lockedCells) {
      if (cell.x < minX) minX = cell.x;
      if (cell.x > maxX) maxX = cell.x;
      if (cell.y < minY) minY = cell.y;
      if (cell.y > maxY) maxY = cell.y;
    }

    const tSpinResult = detectTSpin(
      s.board,
      piece,
      s.lastActionWasRotation,
      s.lastKickIndex,
      s.lastRotationWas180
    );

    const isTSpin = tSpinResult !== 'none';
    const isOtherSpin =
      s.lastActionWasRotation &&
      (piece.type === 'L' || piece.type === 'J' || piece.type === 'S' || piece.type === 'Z' || piece.type === 'I') &&
      s.lastKickIndex > 0;
    const isSpin = isTSpin || isOtherSpin;

    // Clean lock sheen flash & glare
    setLockFlash({
      cells: lockedCells,
      type: piece.type,
      minX,
      maxX,
      minY,
      maxY,
      isHardDrop: isFromHardDrop,
      isSpin,
      spinType: isSpin ? piece.type : undefined,
      spinDirection: s.lastRotationDirection,
      timestamp: Date.now(),
    });
    setTimeout(() => {
      setLockFlash(null);
    }, 320);

    const newBoard = lockPieceToBoard(s.board, piece);

    // Line clearing check
    const { newBoard: boardAfterClear, clearedRowIndices, isAllClear } = checkAndClearLines(newBoard);
    const linesCleared = clearedRowIndices.length;
    let pointsEarned = 0;
    let newCombo = s.currentCombo;
    let newB2B = s.isB2BActive;

    if (linesCleared > 0) {
      newCombo++;
      if (tSpinResult !== 'none') {
        soundManager.playTSpin();
      } else {
        soundManager.playLineClear(linesCleared);
      }
      if (newCombo > 0) {
        soundManager.playCombo(newCombo);
      }
    } else {
      newCombo = -1;
      if (tSpinResult !== 'none') {
        soundManager.playTSpin();
      }
    }

    const scoring = calculateScoring(
      linesCleared,
      tSpinResult,
      s.isB2BActive,
      newCombo,
      isAllClear,
      s.stats.level
    );

    pointsEarned += scoring.points;
    if (scoring.triggersB2B) {
      newB2B = true;
    } else if (linesCleared > 0) {
      newB2B = false;
    }

    let lineClearColor = '#38e8ff';
    if (scoring.actionText) {
      if (scoring.actionText.includes('TETRIS')) {
        lineClearColor = '#38e8ff';
      } else if (scoring.actionText.includes('T-SPIN')) {
        lineClearColor = '#e879f9';
      } else if (scoring.actionText.includes('PERFECT CLEAR')) {
        lineClearColor = '#fcd34d';
      } else if (scoring.actionText.includes('TRIPLE')) {
        lineClearColor = '#c084fc';
      } else if (scoring.actionText.includes('DOUBLE')) {
        lineClearColor = '#34d399';
      } else {
        lineClearColor = '#60a5fa';
      }
      showBanner(scoring.actionText, newCombo > 0 ? `${newCombo} COMBO!` : undefined, lineClearColor);
    }

    const newLines = s.stats.lines + linesCleared;
    const newPieces = s.stats.pieces + 1;
    let newLevel = s.stats.level;

    if (s.mode === 'marathon') {
      const targetLines = getMarathonTargetLines(s.startLevel);
      if (newLines >= targetLines) {
        s.isWon = true;
        setIsWon(true);
        soundManager.playLevelUp();
        showBanner('MARATHON COMPLETE!', `Cleared ${targetLines} Lines!`, '#ffd200');
      } else {
        const calcLevel = getMarathonLevel(newLines, s.startLevel);
        if (calcLevel > newLevel) {
          newLevel = calcLevel;
          soundManager.playLevelUp();
          const lvlId = Date.now();
          setLevelBanner({ id: lvlId, level: newLevel });
          setTimeout(() => {
            setLevelBanner((curr) => (curr?.id === lvlId ? null : curr));
          }, 1800);
        }
      }
    }

    if (s.mode === 'sprint' && newLines >= 40) {
      s.isWon = true;
      setIsWon(true);
      soundManager.playLevelUp();
      showBanner('SPRINT FINISHED!', `Time: ${(s.stats.timeElapsed / 1000).toFixed(2)}s`, '#00d2ff');
    }

    s.isB2BActive = newB2B;
    s.currentCombo = newCombo;
    s.canHold = true;
    setCanHold(true);

    s.stats = {
      ...s.stats,
      score: s.stats.score + pointsEarned,
      lines: newLines,
      level: newLevel,
      pieces: newPieces,
      tetrises: s.stats.tetrises + (linesCleared === 4 ? 1 : 0),
      tspins: s.stats.tspins + (tSpinResult !== 'none' ? 1 : 0),
      combos: newCombo > 0 ? s.stats.combos + 1 : s.stats.combos,
      maxCombo: Math.max(s.stats.maxCombo, newCombo),
      b2bCount: s.stats.b2bCount + (scoring.triggersB2B && s.isB2BActive ? 1 : 0),
    };
    setStats({ ...s.stats });

    // Update board with the locked piece first
    s.board = newBoard;
    setBoard(newBoard);
    s.activePiece = null;
    setActivePiece(null);

    // Guideline A1.2.1: the next tetrimino is generated 0.2 seconds after
    // Lock down. The game loop performs the actual spawn once the delay
    // has elapsed (line clear animation and generation phase run
    // concurrently, as separate engine phases).
    s.pendingSpawn = true;
    s.spawnDelayTimer = 0;

    // Line Clear Phase (animation only — collapse happens here, spawn in the loop)
    if (linesCleared > 0) {
      setClearingRows(clearedRowIndices);
      if (lineClearTimeoutRef.current) {
        clearTimeout(lineClearTimeoutRef.current);
      }
      lineClearTimeoutRef.current = setTimeout(() => {
        lineClearTimeoutRef.current = null;
        setClearingRows([]);
        s.board = boardAfterClear;
        setBoard(boardAfterClear);
      }, GUIDELINE_LINE_CLEAR_DELAY);
    }
  }, [showBanner]);

  const moveLeft = useCallback(() => {
    const s = stateRef.current;
    if (!s.activePiece) {
      // Buffer a left press during the 0.2s generation phase (A1.2.1) so it
      // applies the moment the next tetrimino appears instead of being lost
      if (s.pendingSpawn && !s.isPaused && !s.isGameOver && !s.isWon) {
        s.bufferedMove = -1;
      }
      return;
    }
    if (s.isPaused || s.isGameOver || s.isWon) return;

    const res = tryMovePiece(s.board, s.activePiece, -1, 0);
    if (res.success) {
      const groundedAfter = checkCollision(
        s.board,
        res.piece.type,
        res.piece.rotation,
        res.piece.x,
        res.piece.y + 1
      );
      s.hasBumpedLeft = false;
      s.hasBumpedRight = false;
      s.activePiece = res.piece;
      s.lastActionWasRotation = false;
      // Guideline 5.7 + A1.2.3: only a move that leaves the tetrimino on a
      // Surface resets the lock timer. Sliding off a ledge pauses the timer
      // instead of granting a fresh 0.5 seconds.
      if (groundedAfter && res.piece.lockMovesCount <= MAX_LOCK_MOVES) {
        s.lockTimer = 0;
      }
      soundManager.playMove();
      setActivePiece({ ...res.piece });
      const gy = getGhostPieceY(s.board, res.piece);
      setGhostY(gy);
    } else {
      if (!s.hasBumpedLeft) {
        s.hasBumpedLeft = true;
        if (s.settings.matrixShakeEnabled !== false) {
          setMatrixShake('bump-left');
          setTimeout(() => {
            setMatrixShake((cur) => (cur === 'bump-left' ? null : cur));
          }, 140);
        }
      }
    }
  }, []);

  const moveRight = useCallback(() => {
    const s = stateRef.current;
    if (!s.activePiece) {
      // Buffer a right press during the generation phase (see moveLeft)
      if (s.pendingSpawn && !s.isPaused && !s.isGameOver && !s.isWon) {
        s.bufferedMove = 1;
      }
      return;
    }
    if (s.isPaused || s.isGameOver || s.isWon) return;

    const res = tryMovePiece(s.board, s.activePiece, 1, 0);
    if (res.success) {
      const groundedAfter = checkCollision(
        s.board,
        res.piece.type,
        res.piece.rotation,
        res.piece.x,
        res.piece.y + 1
      );
      s.hasBumpedLeft = false;
      s.hasBumpedRight = false;
      s.activePiece = res.piece;
      s.lastActionWasRotation = false;
      // Guideline 5.7 + A1.2.3: see moveLeft
      if (groundedAfter && res.piece.lockMovesCount <= MAX_LOCK_MOVES) {
        s.lockTimer = 0;
      }
      soundManager.playMove();
      setActivePiece({ ...res.piece });
      const gy = getGhostPieceY(s.board, res.piece);
      setGhostY(gy);
    } else {
      if (!s.hasBumpedRight) {
        s.hasBumpedRight = true;
        if (s.settings.matrixShakeEnabled !== false) {
          setMatrixShake('bump-right');
          setTimeout(() => {
            setMatrixShake((cur) => (cur === 'bump-right' ? null : cur));
          }, 140);
        }
      }
    }
  }, []);

  const softDrop = useCallback(() => {
    const s = stateRef.current;
    if (!s.activePiece) {
      // Buffer a soft-drop press during the 0.2s generation phase so it applies
      // to the next tetrimino as soon as it appears
      if (s.pendingSpawn && !s.isPaused && !s.isGameOver && !s.isWon) {
        s.bufferedSoftDrop = true;
      }
      return;
    }
    if (s.isPaused || s.isGameOver || s.isWon) return;

    const oldLowestY = s.activePiece.lowestY;
    const res = tryMovePiece(s.board, s.activePiece, 0, 1);
    if (res.success) {
      s.activePiece = res.piece;
      s.lastActionWasRotation = false;
      // Guideline A1.2.3: landing on a lower Surface resets the timer; falling
      // back through rows already reached only resumes the paused timer.
      if (res.piece.y > oldLowestY && res.piece.lockMovesCount <= MAX_LOCK_MOVES) {
        s.lockTimer = 0;
      }
      s.gravityAccumulator = 0;
      s.stats.score += 1;
      soundManager.playSoftDrop();
      setActivePiece({ ...res.piece });
      setStats({ ...s.stats });
    } else {
      s.isGrounded = true;
    }
  }, []);

  const hardDrop = useCallback(() => {
    const s = stateRef.current;
    const piece = s.activePiece;
    if (!piece) {
      // Buffer a hard-drop press during the 0.2s generation phase so the next
      // tetrimino locks down instantly when it appears
      if (s.pendingSpawn && !s.isPaused && !s.isGameOver && !s.isWon) {
        s.bufferedHardDrop = true;
      }
      return;
    }
    if (s.isPaused || s.isGameOver || s.isWon) return;

    const gy = getGhostPieceY(s.board, piece);
    const dropDistance = gy - piece.y;
    s.stats.score += dropDistance * 2;

    const shape = PIECE_SHAPES[piece.type][piece.rotation];

    // Compute column contact heights
    const colInfoMap = new Map<number, number>(); // col -> bottomY
    for (let c = 0; c < shape[0].length; c++) {
      let maxR = -1;
      for (let r = 0; r < shape.length; r++) {
        if (shape[r][c] !== 0) {
          maxR = r;
        }
      }
      if (maxR !== -1) {
        const colX = piece.x + c;
        colInfoMap.set(colX, gy + maxR + 1);
      }
    }

    const sortedCols = Array.from(colInfoMap.keys()).sort((a, b) => a - b);
    const minCol = sortedCols[0];
    const maxCol = sortedCols[sortedCols.length - 1];
    const totalSpan = maxCol - minCol + 1;

    // Build contiguous horizontal spans of identical landing contact height
    // This ensures contiguous bars (like horizontal I) produce a single unified shockwave, NOT dotted dashes!
    const spans: ContiguousImpactSpan[] = [];
    if (sortedCols.length > 0) {
      let curStart = sortedCols[0];
      let curSpan = 1;
      let curBottomY = colInfoMap.get(curStart)!;

      for (let i = 1; i < sortedCols.length; i++) {
        const c = sortedCols[i];
        const by = colInfoMap.get(c)!;
        if (c === curStart + curSpan && by === curBottomY) {
          curSpan++;
        } else {
          spans.push({ startCol: curStart, spanCols: curSpan, bottomY: curBottomY });
          curStart = c;
          curSpan = 1;
          curBottomY = by;
        }
      }
      spans.push({ startCol: curStart, spanCols: curSpan, bottomY: curBottomY });
    }

    // Unified drop trail: only spawn if piece actually fell through at least 1 row
    if (gy > piece.y) {
      if (hardDropTrailTimeoutRef.current) {
        clearTimeout(hardDropTrailTimeoutRef.current);
        hardDropTrailTimeoutRef.current = null;
      }
      setHardDropTrail({
        startCol: minCol,
        spanCols: totalSpan,
        startY: piece.y,
        endY: gy,
        type: piece.type,
        timestamp: Date.now(),
      });
      hardDropTrailTimeoutRef.current = setTimeout(() => {
        setHardDropTrail(null);
        hardDropTrailTimeoutRef.current = null;
      }, 90);
    } else {
      setHardDropTrail(null);
    }

    // Hard drop landing impact: unified contiguous shockwave lines
    if (hardDropImpactTimeoutRef.current) {
      clearTimeout(hardDropImpactTimeoutRef.current);
      hardDropImpactTimeoutRef.current = null;
    }
    setHardDropImpact({
      spans,
      type: piece.type,
      timestamp: Date.now(),
    });
    hardDropImpactTimeoutRef.current = setTimeout(() => {
      setHardDropImpact(null);
      hardDropImpactTimeoutRef.current = null;
    }, 120);

    // Physical matrix drop dip with gentle inertia
    if (s.settings.matrixShakeEnabled !== false) {
      setMatrixShake('drop');
      setTimeout(() => {
        setMatrixShake((cur) => (cur === 'drop' ? null : cur));
      }, 140);
    }

    if (dropDistance > 0) {
      s.lastActionWasRotation = false;
    }

    piece.y = gy;
    soundManager.playHardDrop();
    lockActivePiece(true);
  }, [lockActivePiece]);

  const rotateCW = useCallback(() => {
    const s = stateRef.current;
    if (!s.activePiece) {
      if (!s.isPaused && !s.isGameOver && !s.isWon) {
        s.bufferedRotate = 'CW';
      }
      return;
    }
    if (s.isPaused || s.isGameOver || s.isWon) return;

    const res = tryRotatePiece(s.board, s.activePiece, 'CW');
    if (res.success) {
      s.lastRotationDirection = 'CW';
      const oldY = s.activePiece.y;
      const newY = res.piece.y;
      const movedDown = newY > oldY;
      const stillGrounded =
        !movedDown &&
        checkCollision(
          s.board,
          res.piece.type,
          res.piece.rotation,
          res.piece.x,
          res.piece.y + 1
        );

      s.hasBumpedLeft = false;
      s.hasBumpedRight = false;
      s.activePiece = res.piece;
      s.lastActionWasRotation = true;
      s.lastKickIndex = res.kickIndex;
      s.lastRotationWas180 = false;

      if (res.piece.lockMovesCount <= MAX_LOCK_MOVES) {
        if (movedDown) {
          // Rotation kicked the piece down onto a lower surface: fresh lock
          s.lockTimer = 0;
        } else if (stillGrounded) {
          // Rotated in place while grounded: reset per Section 5.7
          s.lockTimer = 0;
        }
        // else: lifted off the surface — timer pauses, resumes on next landing (A1.2.3)
      }
      soundManager.playRotate();
      setActivePiece({ ...res.piece });
      const gy = getGhostPieceY(s.board, res.piece);
      setGhostY(gy);
    }
  }, []);

  const rotateCCW = useCallback(() => {
    const s = stateRef.current;
    if (!s.activePiece) {
      if (!s.isPaused && !s.isGameOver && !s.isWon) {
        s.bufferedRotate = 'CCW';
      }
      return;
    }
    if (s.isPaused || s.isGameOver || s.isWon) return;

    const res = tryRotatePiece(s.board, s.activePiece, 'CCW');
    if (res.success) {
      s.lastRotationDirection = 'CCW';
      const oldY = s.activePiece.y;
      const newY = res.piece.y;
      const movedDown = newY > oldY;
      const stillGrounded =
        !movedDown &&
        checkCollision(
          s.board,
          res.piece.type,
          res.piece.rotation,
          res.piece.x,
          res.piece.y + 1
        );

      s.hasBumpedLeft = false;
      s.hasBumpedRight = false;
      s.activePiece = res.piece;
      s.lastActionWasRotation = true;
      s.lastKickIndex = res.kickIndex;
      s.lastRotationWas180 = false;

      if (res.piece.lockMovesCount <= MAX_LOCK_MOVES) {
        if (movedDown) {
          s.lockTimer = 0;
        } else if (stillGrounded) {
          s.lockTimer = 0;
        }
      }
      soundManager.playRotate();
      setActivePiece({ ...res.piece });
      const gy = getGhostPieceY(s.board, res.piece);
      setGhostY(gy);
    }
  }, []);

  const rotate180 = useCallback(() => {
    const s = stateRef.current;
    if (!s.activePiece) {
      if (!s.isPaused && !s.isGameOver && !s.isWon) {
        s.bufferedRotate = '180';
      }
      return;
    }
    if (s.isPaused || s.isGameOver || s.isWon) return;

    const res = tryRotatePiece(s.board, s.activePiece, '180');
    if (res.success) {
      s.lastRotationDirection = '180';
      const oldY = s.activePiece.y;
      const newY = res.piece.y;
      const movedDown = newY > oldY;
      const stillGrounded =
        !movedDown &&
        checkCollision(
          s.board,
          res.piece.type,
          res.piece.rotation,
          res.piece.x,
          res.piece.y + 1
        );

      s.hasBumpedLeft = false;
      s.hasBumpedRight = false;
      s.activePiece = res.piece;
      s.lastActionWasRotation = true;
      s.lastKickIndex = res.kickIndex;
      s.lastRotationWas180 = true;

      if (res.piece.lockMovesCount <= MAX_LOCK_MOVES) {
        if (movedDown) {
          s.lockTimer = 0;
        } else if (stillGrounded) {
          s.lockTimer = 0;
        }
      }
      soundManager.playRotate180();
      setActivePiece({ ...res.piece });
      const gy = getGhostPieceY(s.board, res.piece);
      setGhostY(gy);
    }
  }, []);

  const hold = useCallback(() => {
    const s = stateRef.current;
    if (!s.activePiece) {
      if (!s.isPaused && !s.isGameOver && !s.isWon && s.canHold) {
        s.bufferedHold = true;
      }
      return;
    }
    if (!s.canHold || s.isPaused || s.isGameOver || s.isWon) return;

    soundManager.playHold();
    s.hasBumpedLeft = false;
    s.hasBumpedRight = false;

    const currentType = s.activePiece.type;
    const nextHold = currentType;

    if (s.holdPiece === null) {
      s.holdPiece = nextHold;
      setHoldPiece(nextHold);
      s.canHold = false;
      setCanHold(false);
      s.activePiece = null;
      setActivePiece(null);
      spawnNext();
    } else {
      const toSpawnType = s.holdPiece;
      s.holdPiece = nextHold;
      setHoldPiece(nextHold);
      s.canHold = false;
      setCanHold(false);

      const swappedPiece = spawnPiece(toSpawnType);
      if (!checkCollision(s.board, swappedPiece.type, swappedPiece.rotation, swappedPiece.x, swappedPiece.y + 1)) {
        swappedPiece.y += 1;
        swappedPiece.lowestY = swappedPiece.y;
      }
      s.activePiece = swappedPiece;
      s.lastActionWasRotation = false;
      s.lastKickIndex = 0;
      s.lockTimer = 0;
      s.isGrounded = checkCollision(s.board, swappedPiece.type, swappedPiece.rotation, swappedPiece.x, swappedPiece.y + 1);
      setActivePiece({ ...swappedPiece });
      const gy = getGhostPieceY(s.board, swappedPiece);
      setGhostY(gy);
    }
  }, [spawnNext]);

  const resetWallBump = useCallback(() => {
    stateRef.current.hasBumpedLeft = false;
    stateRef.current.hasBumpedRight = false;
  }, []);

  // Sync ref functions for IRS/IHS
  rotateCWRef.current = rotateCW;
  rotateCCWRef.current = rotateCCW;
  rotate180Ref.current = rotate180;
  holdRef.current = hold;

  const togglePause = useCallback(() => {
    stateRef.current.isPaused = !stateRef.current.isPaused;
    setIsPaused(stateRef.current.isPaused);
    if (stateRef.current.isPaused) {
      setHardDropTrail(null);
      setHardDropImpact(null);
    }
  }, []);

  useEffect(() => {
    let animId: number;
    let lastTimeUpdate = 0;

    const loop = (timestamp: number) => {
      const s = stateRef.current;
      const dt = Math.min(100, timestamp - s.lastFrameTime);
      s.lastFrameTime = timestamp;

      if (!s.isPaused && !s.isGameOver && !s.isWon) {
        s.stats.timeElapsed += dt;
        if (s.mode === 'ultra' && s.stats.remainingTime !== undefined) {
          s.stats.remainingTime = Math.max(0, s.stats.remainingTime - dt);
          if (s.stats.remainingTime <= 0) {
            s.isWon = true;
            setIsWon(true);
            soundManager.playLevelUp();
            showBanner('TIME UP!', `Score: ${s.stats.score}`, '#ffd200');
          }
        }

        // Guideline A1.2.1: generate the next tetrimino 0.2s after Lock down
        if (s.pendingSpawn && !s.activePiece) {
          s.spawnDelayTimer += dt;
          if (s.spawnDelayTimer >= SPAWN_DELAY_MS) {
            s.pendingSpawn = false;
            s.spawnDelayTimer = 0;
            spawnNext();
          }
        }

        if (s.activePiece) {
          const isCurrentlyGrounded = checkCollision(
            s.board,
            s.activePiece.type,
            s.activePiece.rotation,
            s.activePiece.x,
            s.activePiece.y + 1
          );
          s.isGrounded = isCurrentlyGrounded;

          if (isCurrentlyGrounded) {
            s.lockTimer += dt;
            if (s.lockTimer >= LOCK_DELAY_MS) {
              lockActivePiece();
            }
          } else {
            // Guideline Section 7: at high levels a row may take less than one
            // frame to fall (L14 = 11ms/row ≈ 90 rows/s, L15 = 7ms/row ≈ 143
            // rows/s), so step down as many rows as the accumulator affords.
            const fallSpeed = getFallSpeed(s.stats.level, s.mode);
            s.gravityAccumulator += dt;
            let steps = 0;
            let gravityMoved = false;
            while (s.gravityAccumulator >= fallSpeed && steps < 30 && s.activePiece) {
              const oldLowestY = s.activePiece.lowestY;
              const res = tryMovePiece(s.board, s.activePiece, 0, 1);
              if (!res.success) {
                // Grounded: no debt carries over to the next frame
                s.gravityAccumulator = 0;
                break;
              }
              s.gravityAccumulator -= fallSpeed;
              steps++;
              s.activePiece = res.piece;
              s.lastActionWasRotation = false;
              if (res.piece.y > oldLowestY) {
                s.lockTimer = 0;
              }
              gravityMoved = true;
            }
            if (gravityMoved && s.activePiece) {
              setActivePiece({ ...s.activePiece });
              setGhostY(getGhostPieceY(s.board, s.activePiece));
            }
          }
        }

        // Throttle time state updates to 100ms to prevent React thrashing
        if (timestamp - lastTimeUpdate >= 100) {
          lastTimeUpdate = timestamp;
          setStats({ ...s.stats });
        }
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [lockActivePiece, showBanner, spawnNext]);

  useEffect(() => {
    const isAutostart =
      typeof window !== 'undefined' &&
      new URLSearchParams(window.location.search).get('autostart') === '1';

    startNewGame(initialMode);
    if (!isAutostart) {
      stateRef.current.isPaused = true;
      setIsPaused(true);
    }
  }, []);

  return {
    mode,
    setMode,
    board,
    activePiece,
    ghostY,
    holdPiece,
    canHold,
    nextQueue,
    stats,
    isPaused,
    isGameOver,
    isWon,
    settings,
    setSettings,
    actionBanners,
    levelBanner,
    clearingRows,
    hardDropTrail,
    hardDropImpact,
    matrixShake,
    lockFlash,
    startNewGame,
    moveLeft,
    moveRight,
    softDrop,
    hardDrop,
    rotateCW,
    rotateCCW,
    rotate180,
    hold,
    togglePause,
    resetWallBump,
    debugSetBoard: (updater: (b: BoardMatrix) => void) => {
      updater(stateRef.current.board);
      setBoard([...stateRef.current.board.map((r) => [...r])]);
      if (stateRef.current.activePiece) {
        setGhostY(getGhostPieceY(stateRef.current.board, stateRef.current.activePiece));
      }
    },
  };
}

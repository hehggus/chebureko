Customizing songs:
    Add or remove songs in the 'audio' folder. Songs need to be in a tracker
    format (specifically either .mod, .it, .xm or .s3m). The limits are
    that songs need to use 8 channels at most, the max ROM size for GBA (32MB)
    and the game has a software limit of 255 songs for the menu and game categories each.
    You can specify if the songs are going to play during menus or in-game by
    adding 'MENU_' or 'GAME_' respectively in front of the song's name.

Customizing sound effects:
    Replace any of the sound effects in the 'audio' folder with ones with the
    same file name.

WINDOWS:
    After any changes, run 'WINDOWS_build.bat' to add them to the ROM.

LINUX:
    Python is required to build songs. After any changes, run 'LINUX_or_MAC_build.sh' to add them to the ROM.

MAC:
    Run the LINUX_or_MAC_build.sh to add any changes to the ROM.

Patching for unique hardware:
    IF YOU USE ONE OF THESE:
    - EZFlash Air flash cart
    - Analogue Pocket with a Rumble Cart
    You will need to patch your 'Apotris.gba' (or 'audio/Apotris-base.gba' before running the script for custom music).
    In the 'patches' folder are .ups files named for each target. You can use any tool that supports UPS patch format.
    RomPatcherJS is a great option that works on both desktop and mobile: https://www.marcrobledo.com/RomPatcher.js/

Building and selecting audio:
    Use lowercase music file extensions.
    Run the scripts from the extracted release folder; Linux/macOS require Python 3.
    The scripts produce Apotris.gba. Base ROM for patching: tools/Apotris-base.gba.
    Preview or disable songs in Settings > Audio > Track List.

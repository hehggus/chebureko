
BASE_PATH="./sprites/placeEffect/"
OUTPUT="./data/"

for f in $BASE_PATH
do
    for sprite in ${f}*.png
    do
        name=${sprite##*/}
        ./tools/superfamiconv -v -i "$sprite" -t "$OUTPUT${name%.*}"_tiles.bin -M gba -R -D
    done
done
